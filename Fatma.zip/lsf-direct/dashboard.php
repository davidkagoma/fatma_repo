<?php
ob_start();
session_start();
$activePage = 'dashboard';
include_once './includes/session.php';
include_once 'dashboardservice.php';
include_once './includes/header.php';

$title = "LSF | Dashboard";
$pageContents = ob_get_contents();

ob_end_clean();
echo str_replace('<!--TITLE-->', $title, $pageContents);
?>
<!--<div class="navbar-tools">

</div>-->

<!--<div class="col-xs-6 col-md-2">

</div>
<div class="col-xs-6 col-md-8">
<?php
//    include_once './includes/top.php';
?>    
</div>
</div>
</div>
</div>-->
<?php include 'includes/bottom_header_part.php'; ?>

<!-- START V2 PANNELS-->
<style type="text/css">
    .panel-footer {
        
        background-color: white !important;
        
    }
    </style>
<div class="row">
    <div class="col-xs-12 col-sm-6 col-md-3" id="side_menu">   
           
        <?php
        include('includes/side_menu.php');
        ?>
         
<!--        <button class="btn btn-default" href="#" id="showmenu">    
            <i class="fa fa-align-justify"></i>  
        </button>-->
    </div>
    <div class="col-xs-12 col-sm-6 col-md-3"></div>
    <div class="col-xs-12 col-sm-6 col-md-9"> 
        <div class="panel panel-default" id="style_top_pannels">
            <div class="panel-body">

            </div>
        </div>
        
        <div class="col-xs-12 col-sm-6 col-md-4"> 
            <br>
            <div class="list-group" id="summary_box">
                <a href="#" class="list-group-item ">
                    <p class="text-center"> <b class="text-success">Paralegal Summary </b></p>
                </a>
                <li class="list-group-item">
                    <span class="badge"><?php echo $paralegal; ?></span>
                    Paralegals
                </li>
                <li class="list-group-item">
                    <span class="badge"><?php echo 4; ?></span>
                    Paralegal Units
                </li>  
                <li class="list-group-item">
                    <span class="badge"></span>
                    <br/>
                </li> 
            </div>
        </div>
        
        <div class="col-xs-12 col-sm-6 col-md-4"> 
            <br>
            <div class="list-group">
                <a href="#" class="list-group-item ">
                    <p class="text-center"> <b class="text-warning">  Legal Summary </b></p>

                </a>
                <li class="list-group-item">
                    <span class="badge"><?php echo number_format($aidclients); ?></span>
                    Legal Aid Client Reach
                </li>
                <li class="list-group-item">
                    <span class="badge"><?php echo number_format($aidclients); ?></span>
                    Legal Aid Dispute Reach
                </li>
            </div></div><div class="col-xs-12 col-sm-6 col-md-4">
                <br>
            <div class="panel panel-info" style="background-color: white !important">
                <div class="panel-body">
                    <center><b class="text-center text-info">  Legal Aid Client by Gender </b></center>

                </div>
                <div class="panel-footer" id="position_table_pannel">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                            <th><center>Male</center></th>
                        <th><center>Female</center></th>
                            <th><b class="text-success">Total</b></th>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><center><?php echo number_format($aidmale); ?></center></td>
                                    <td><center><?php echo number_format($aidfemale); ?></center></td>
                                    <td><b class="text-success"><?php echo number_format($aidmale + $aidfemale); ?></b></td>
                                </tr>
                            </tbody>
                        </table>
                       
                    </div>    
                </div>
            </div></div>
        <div class="panel panel-default" id="style_top_pannels_">
            <div class="panel-body">

            </div>
        </div>
        <div class="col-xs-12 col-sm-6 col-md-4"> 
            <br><br/>
            <div class="panel panel-info" id="position_table_pannel_1">
                <div class="panel-body">
                   <center> <b class="text-danger">  Legal Education by Gender </b></center>

                </div>
                <div class="panel-footer" style="background-color:white !important">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                            <th><center>Male</center></th>
                            <th><center>Female</center></th>
                            <th><center><b class="text-success">Total</b></center></th>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><center><?php echo number_format($edumale); ?></center></td>
                                    <td><center><?php echo number_format($edufemale); ?></center></td>
                                    <td><center><b class="text-success"><?php echo number_format($edumale + $edufemale); ?></b></center></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>    
                </div>
            </div></div>
        
        <div class="col-xs-12 col-sm-6 col-md-8">                                 
            
            <p class="text-center" style="padding-top: 4px"><span class="label label-success">Paralegal Performance by Unit</span></p>
            
            <div class="panel-footer">
                <?php if($_SESSION['type']=='super admin'){?>
                <table class="table">
                    <thead>
                    <th>Unit Name</th>
                    <th>Legal Education  Reach</th>
                    <th>Legal Aid Dispute Reach</th>                   
                    </thead>
                    <tbody>
                        <tr>
                            <td><label style="size:10px;font-stretch:condensed;cursor:pointer" onClick="viewParalegalperformance($(this))">Kisarawe Paralegals Unit</label></td>
                            <td><center>
                                <?php
                                $cnt = getCount('LegalEducationDirectView', 'Kisarawe paralegals unit');
                                echo "<center>".number_format($cnt)."</center>";
                                ?>
                           </center> </td>
                            <td><center>
                                <?php
                                $cnt = getCount('LegalAidDirectView', 'Kisarawe paralegals unit');
                                echo number_format($cnt);
                                ?>
                            </center></td>
                        </tr>
                        <!-- 2nd row -->
                        <tr>
                           <td><label style="size:10px;font-stretch:condensed;cursor:pointer" onClick="viewParalegalperformance($(this))">ZAPAO-Zanzibar</label></td>
                            <td>
                                <?php
                                $cnt = getCount('LegalEducationDirectView', 'ZAPAO-Zanzibar');
                                echo "<center>".number_format($cnt)."</center>";
                                ?>
                            </td>
                            <td>
                                <?php
                                $cnt = getCount('LegalAidDirectView', 'ZAPAO-Zanzibar');
                                echo "<center>".number_format($cnt)."</center>";
                                ?>
                            </td>
                        </tr>
                        <!-- 3rd row -->
                        <tr>
                            <td><label style="size:10px;font-stretch:condensed;cursor:pointer" onClick="viewParalegalperformance($(this))">Rungwe Paralegals Unit</label></td>
                            <td>
                                <?php
                                $cnt = getCount('LegalEducationDirectView', 'Rungwe paralegals Unit');
                                echo "<center>".number_format($cnt)."</center>";
                                ?>
                            </td>
                            <td>
                                <?php
                                $cnt = getCount('LegalAidDirectView', 'Rungwe paralegals Unit');
                                echo "<center>".number_format($cnt)."</center>";
                                ?>
                            </td>
                        </tr>

                        <!-- 4th row -->
                        <tr>
                            <td><label style="size:10px;font-stretch:condensed;cursor:pointer" onClick="viewParalegalperformance($(this))">Babati Paralegals Unit</label></td>
                            <td>
                                <?php
                                $cnt = getCount('LegalEducationDirectView', 'Babati paralegals Unit');
                                echo "<center>".number_format($cnt)."</center>";
                                ?>
                            </td>
                            <td>
                                <?php
                                $cnt = getCount('LegalAidDirectView', 'Babati paralegals Unit');
                                echo "<center>".number_format($cnt)."</center>";
                                ?>
                            </td>
                        </tr>
                    </tbody>
                </table> 
                <?php } else{
                    $sql = "SELECT unit_id from paralegals where login_id = {$_SESSION['loginid']}";
                          $result =  $query :: select($sql);
                          $resultarray = array();
                          $unitname = mysql_fetch_row($result);
                          $unitname = $unitname[0];
                          
                          $sql = "SELECT unit_name from LegalAidDirectView where unit_id = $unitname ";
                          
                          $result =  $query :: select($sql);
                          
                          $resultarray = array();
                          $unitname = mysql_fetch_row($result);
                          $unitname = $unitname[0];
                    ?>
                <table class="table">
                    <thead>
                    <th>Unit Name</th>
                    <th>Legal Education  Reach</th>
                    <th>Legal Aid Dispute Reach</th>                   
                    </thead>
                    <tbody>
                        <tr><td><?php echo $unitname; ?></td><td><?php $cnt =  getCount('LegalEducationDirectView',$unitname); echo "<center><label style='size:10px;color:black;font-stretch:condensed'>".number_format($cnt)."</label><center>"?></td><td><?php $cnt =  getCount('LegalAidDirectView',$unitname); echo "<center><label style='size:10px;color:black;font-stretch:condensed'>".number_format($cnt)."</label><center>"?></td></tr>
                        </tbody>    
                    </table>
                <?php }?>
            </div>
        </div>
        <div class="panel panel-default" id="style_top_pannels_">
            <div class="panel-body">

            </div>
        </div>
        <div class="panel panel-default" id="style_top_pannels_">
            <div class="panel-body">

            </div>
        </div>
        <div class="col-xs-12 col-sm-6 col-md-12">
            
            <p class="text-center" style="padding-top:13px"><span class="label label-info">Monthly Average Dispute Report</span></p>
            <div id="disputes-monthly" >      
            </div> 
        </div> 
        <div class="panel panel-default" id="style_top_pannels">
            <div class="panel-body">

            </div>
        </div>
    </div>
    <!-- end-->



    <!-- THIRD ROW -->


    <!-- 4th RAW-->


    <!-- END OF V2-->

</div>


<?php
include_once './includes/footer.php';
?>
