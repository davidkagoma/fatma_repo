<?php
ob_start();
session_start();
$activePage = 'dashboard';
include_once  'dashboardreportservice.php';
include_once './includes/session.php';
include_once './includes/header.php';

$title = "LSF | Dashboard";
$pageContents = ob_get_contents ();

ob_end_clean (); 
echo str_replace ('<!--TITLE-->', $title, $pageContents);
?>
<div class="navbar-tools">
                      <?php                        
                      include_once './includes/top.php';
                      ?>
                    </div>
                    </div>    
                </div>
             <div class="main-container">
                <div class="navbar-content">
                  
                    <div class="main-navigation navbar-collapse collapse">
                        
                        <div class="navigation-toggler">
                            <i class="clip-chevron-left"></i>
                            <i class="clip-chevron-right"></i>
                        </div>
                        
                        <?php include('includes/menu.php'); ?>
                    </div>
                   
                </div>
             </div>
                
                <div class="main-content" >
                    <div class="container">
                        <!-- start: PAGE HEADER -->
                        <div class="row">
                            <div class="col-sm-12">
                                
                                
                                
                                
                                
                                <div class="divider">
                                 <li>
                                 <a href="#">
                                 </a>
                                 </li>
                                 
                               
                                 </div>
                                
                                
                                <h1></h1>
                                </div>
                              </div>
                    
                        <div class="row">
                        <div class="col-md-6">
                            <div class="panel panel-default">
                <div class="panel-heading">Legal Education reach by sex</div>
                <div class="panel-body">
                        <div  id="educationgenderbase">
                            
                            
                            
                        </div>
                </div>
                            </div>
                            <div class="panel panel-default">
                <div class="panel-heading">Status of Case Reported </div>
                <div class="panel-body">
                        <div  id="totdisputes">
                        </div>
                </div>
                            </div>
                               <div class="panel panel-default">
                <div class="panel-heading">Clients' gender distribution by case types of resolved disputes</div>
                <div class="panel-body">
                        <div  id="casetype">
                            
                        </div>
                </div>
                            </div>
                            
                            
                             <div class="panel panel-default">
                <div class="panel-heading">Case reported to Paralegals by case type and gender</div>
                <div class="panel-body">
                        <div  id="gendertypepercent">
                            
                        </div>
                </div>
                            </div>
                            
                            
                            <div class="panel panel-default">
                <div class="panel-heading">GBV Based on gender</div>
                <div class="panel-body">
                        <div  id="gbv">
                            
                        </div>
                </div>
                            </div>
                        </div>
                            <div class="col-md-6">
                                <div class="panel panel-default">
                                 <div class="panel panel-default">
                <div class="panel-heading">Number And Type of disputes reported </div>
                <div class="panel-body">
                        <div  id="totcase">
                            
                            
                        </div>
                </div>
                            </div>          
                                 <div class="panel panel-default">
                <div class="panel-heading">Number of case received by sex </div>
                <div class="panel-body">
                        <div  id="gender">
                            
                            
                        </div>
                </div>
                    
                            </div>
                                
                            </div>
                            
                                
                                <div class="panel panel-default">
                <div class="panel-heading">Case reported to Paralegals by case type(%)</div>
                <div class="panel-body">
                        <div  id="casetypepercent">
                            
                            
                            
                        </div>
                </div>
                            </div>
                            
                                
                                
                                <div class="panel panel-default">
                <div class="panel-heading">Case status(%)</div>
                <div class="panel-body">
                        <div  id="casestatusperc">
                            
                            
                            
                        </div>
                </div>
                            </div>
                                
                                <div class="panel panel-default">
                <div class="panel-heading">Source base(%)</div>
                <div class="panel-body">
                        <div  id="sourcebase">
                            
                            
                            
                        </div>
                </div>
                            </div>
                            </div>
                    </div>
                       
                        </div>
                    </div>
                
<?php
  include_once './includes/footer.php';
  include_once 'query.php';
?>