<?php
ob_start();
session_start();

include_once './includes/session.php';

include_once './includes/header.php';
echo "<script type='text/javascript'> var region  = '' </script>";
echo "<script type='text/javascript'> var unit  = '' </script>";
echo "<script type='text/javascript'> var org  = '' </script>";
//$action = 'add';
include_once 'paralegalservice.php';
$title = "LSF | Add Paralegal";
$pageContents = ob_get_contents();
$activePage = 'paralegal';
ob_end_clean();
echo str_replace('<!--TITLE-->', $title, $pageContents);

$regions = array("Arusha", "Dar es Salaam", "Dodoma", "Geita", "Iringa", "Kagera", "Katavi", "Kigoma", "Kilimanjaro",
    "Lindi", "Manyara", "Mara", "Mbeya", "Morogoro", "Mtwara", "Mwanza", "Njombe", "Pemba Kaskazini", "Pemba Kusini", "Pwani",
    "Rukwa", "Ruvuma", "Shinyanga", "Simiyu", "Singida", "Tabora", "Tanga", "Unguja Kaskazini", "Unguja Magharibi", "Zanzibar Kati/Kusini");
?>
<?php include 'includes/bottom_header_part.php'; ?>

<div class="row">
    <div class="col-xs-12 col-sm-6 col-md-3" id="side_menu">
        <?php
        include('includes/side_menu.php');
        ?>
        </div>
    <div class="col-xs-12 col-sm-6 col-md-3"></div>
    <div class="col-xs-12 col-sm-6 col-md-9" id="center_body">
            <div class="panel-body">

                        <h2><?php echo "Add Paralegal Unit"; ?></h2>
                        <hr>

                        <div id="result">


                        </div>
                            <div class="form-group">
                            <label class="col-sm-4 control-label" for="group-name">
                                Zones
                            </label>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <select id="zones" name="zones" class="form-control">
                                        <?php foreach ($zones as $value) { ?>
                                            <option value="<?php echo $value['id']; ?>"><?php echo $value['zone_name']; ?></option>
                                        <?php } ?>
                                    </select>
                                    <label id="error_region" style="color: red;display:none">Region is Missing</label>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-4 control-label" for="group-name">
                                Region
                            </label>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <select id="region" name="region" class="form-control">

                                    </select>
                                    <label id="error_region" style="color: red;display:none">Region is Missing</label>
                                </div>
                            </div>
                        </div>                     
                    
                        <div class="form-group">
                            <label class="col-sm-4 control-label" for="group-name">
                                Unit Name
                            </label>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <input type="text" name="unit" id="unit" class="form-control required" value="">
                                    <label id="error_unit" style="color: red;display:none">Unit is Missing</label>
                                    <label id="errmsg" style="color: red;display:block"></label>
                                </div>
                            </div>
                        </div>
                        
                        
                        <div class="form-group">
                            <label class="col-sm-4 control-label" for="group-name">
                                Organization
                            </label>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <select id="organization" class="form-control">
                                        
                                    </select>
                                    <input type="text" name="neworg" id="neworg" style="display:none" placeholder="Enter new organization"/>
                                </div>
                            </div>
                        </div>
                    <div class="form-group">
                            <label class="col-sm-4 control-label" for="crete">
                            </label>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <a href="#">
                                        <button id="cancel" type="button" class="btn btn-danger">
                                            Cancel <i class="icon-circle-arrow-cross"></i>
                                        </button></a>
                                    <button type="submit" name="saveUnit" id="saveUnit" class="btn btn-primary">
                                        Save <i class="icon-circle-arrow-right"></i>
                                    </button></div>
                            </div>
                        </div>


                    </div> 
        
    </div>
</div>




<?php
include_once './includes/footer.php'
?>
