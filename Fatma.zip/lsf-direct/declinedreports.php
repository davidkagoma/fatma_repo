<?php
ob_start();
session_start();

include_once './includes/session.php';

include_once './includes/header.php';
$title = "LSF | Legal Aid";
$pageContents = ob_get_contents ();
$activePage = 'reports-declined';
ob_end_clean (); 
echo str_replace ('<!--TITLE-->', $title, $pageContents);
?>
<?php include 'includes/bottom_header_part.php'; ?>
<div class="row">
    <div class="col-xs-12 col-sm-6 col-md-3" id="side_menu">
         <?php
        include('includes/side_menu.php');
        ?>
    </div>
    <div class="col-xs-12 col-sm-6 col-md-3"></div>
    <div class="col-xs-12 col-sm-6 col-md-9 " id="center_body">
        <div class="panel panel-default" id="style_top_pannels">
            <a class="label label-danger">PDF Export</a>
            <a class="label label-warning">CVS Export</a>
            <div class="panel-body">
                <div class="col-xs-12 col-sm-6 col-md-12">
                    <form class="form-inline">
                        <div class="col-xs-12 col-sm-6 col-md-12">
                            <div class="form-group">
                                <!--                                <label for="exampleInputName2">STD</label>-->
                                <input type="text" name="std" class="form-control input-sm" id="exampleInputName2" placeholder="Start Date">
                            </div>
                            <div class="form-group">
                                <!--                                <label for="exampleInputEmail2">EDT</label>-->
                                <input type="text" name="edt" class="form-control input-sm" id="exampleInputEmail2" placeholder="End Date">
                            </div>
                            <div class="form-group">                       
                                <!--<input type="text" name="unit" class="form-control" id="exampleInputEmail2" placeholder="Unit">-->
                                <select name="unit" class="form-control input-sm">
                                    <option>All Units</option>
                                    <option>Unit 1</option>
                                    <option>Unit 2</option>
                                    <option>Unit 3</option>
                                </select>
                            </div>

                            </td>
                        </div><div class="col-xs-12 col-sm-6 col-md-12"><br>
                            <div class="collapse" id="collapseExample">
                                <div class="form-group">                       
                                    <input type="text" name="eventType" class="form-control input-sm" id="exampleInputEmail2" placeholder="Event Type">
                                </div>
                                <div class="form-group">                

                                    <select name="gender" class="form-control input-sm">
                                        <option>All Gender</option>
                                        <option>Male</option>
                                        <option>Female</option>                            
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail2">Unit333</label>
                                    <input type="text" name="unit2" class="form-control input-sm" id="exampleInputEmail2" placeholder="jane.doe@example.com">
                                </div>
                                <div class="form-group">
                                    <input class="btn btn-warning" type="submit" value="Search">
                                </div>
                            </div></div>
                    </form>
                </div>
            </div>
              <button class="btn btn-bricky btn-xs dropdown-toggle" type="button" data-toggle="collapse" href="#collapseExample" aria-expanded="false" aria-controls="collapseExample">
            More Filter Options
            <span class="caret"></span>
        </button>
<!-- <button class="btn btn-default btn-xs dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" >
    MORE FILTER OPTIONS <span class="caret"></span>
  </button>-->
        </div>
<!--<div class="navbar-tools">
                      <?php                        
                      //include_once './includes/top.php';
                      ?>
                    </div>
                    </div>    
                </div>-->

<!--             <div class="main-container">
                <div class="navbar-content">
                     start: SIDEBAR 
                    <div class="main-navigation navbar-collapse collapse">
                         start: MAIN MENU TOGGLER BUTTON 
                        <div class="navigation-toggler">
                            <i class="clip-chevron-left"></i>
                            <i class="clip-chevron-right"></i>
                        </div>
                        
                        <?php //include('./includes/menu.php'); ?>
                    </div>
                   
                </div>
             
                
                <div class="main-content">
                    <div class="container">
                         start: PAGE HEADER 
                        <div class="row">
                            
                               <div id="outgoing"> 
                               </div>
                            
                            
                            <div id="incoming"> 
                               </div>
                         </div>
                    <div class="row">
                        <div class="col-sm-12">
                             start: DATE/TIME PICKER PANEL 
                            <div class="panel">
                                <div class="panel-body">
                                    <label class="heading"> Legal-Aid Declined</label>
                                   <div style="display: inline; float: right;" class="form-group tooltip-top">
                                        <table class="downloadbutton">
                                        <tr> 
                                            
                                            <td>
                                        <form action="download.php" method="POST">
                                            <input type="hidden" name="report" value="Legal-Aid-Declined"/>
                                            <select name="export">
                                                <option value="0">Select An Option</option>
                                                <option value="export">Excel</option>
                                                <option value="exportpdf">PDF</option>
                                           </select>
                                           <input type="submit"    name="download" class="btn btn-primary" align="right" value="Download"/>
                                           </form>
                                   </td>
                                   <td>
                                   </td>
                                   </tr>
                                   </table>
                                    </div>
                                    
                                    </div>
                                 end: DATE/TIME PICKER PANEL 
                            </div>
                        </div>
                    </div>    
                        -->
                        
                    
<!--<div class="row nonajax">-->
   <table class="table table-condensed" data-toggle="table" data-url="legalaidservice.php/?action=declined&source=''"  data-show-refresh="true" data-show-toggle="false" data-show-columns="false" data-search="true" data-select-item-name="toolbar1" data-pagination="true" data-sort-name="name" data-sort-order="desc" >
                <thead id="style_top_table" style="font-size: 12px">
                    <tr>
                        
                        <th data-field="Submitted" data-sortable="true">Submitted on</th>
                        <th data-field="phone_number" data-sortable="true">Mobile</th>
                        <th data-field="name" data-sortable="true">Submitted By</th>
                        <th data-field="unit_name" data-sortable="true">Unit</th>
                        <th data-field="gender" data-sortable="true">Gender</th>
                        <th data-field="education" data-sortable="true">Education</th>
                        <th data-field="age" data-sortable="true">Age</th>
                        <th data-field="marital_status">Marital Status</th>
                        <th data-field="case_type" data-sortable="true">Case Type</th>
                        <th data-field="case_status" data-sortable="true">Status</th>
                        
                    </tr>
                    </thead>
                </table>
<!--</div>-->

                        
                        
                        
                        
                        
                </div>
             </div>
<?php
include_once './includes/footer.php';
?>