<?php
session_start();
ob_start();
$activePage = 'editusers';
include_once './includes/session.php';
include_once './includes/header.php';
$title = "LSF | Edit User";
$pageContents = ob_get_contents();

ob_end_clean();
echo str_replace('<!--TITLE-->', "LSF | Edit User", $pageContents);
?>
<?php include 'includes/bottom_header_part.php'; ?>
<!--<div class="navbar-tools">
<?php
// include_once './includes/top.php';
?>
                    </div>
                    </div>    
                </div>-->
<!--                 <div class="main-container">
                <div class="navbar-content">
                     start: SIDEBAR 
                    <div class="main-navigation navbar-collapse collapse">
                         start: MAIN MENU TOGGLER BUTTON 
                        <div class="navigation-toggler">
                            <i class="clip-chevron-left"></i>
                            <i class="clip-chevron-right"></i>
                        </div>
                        
<?php //include('./includes/menu.php'); ?>
                    </div>
                   
                </div>-->
<div class="row">
    <div class="col-xs-12 col-sm-6 col-md-3" id="side_menu">
        <?php
        include('includes/side_menu.php');
        ?>
    </div>
    <div class="col-xs-12 col-sm-6 col-md-3"></div>
    <div class="col-xs-12 col-sm-6 col-md-9 " id="center_body">
        <div class="main-content">
            <!-- start: PANEL CONFIGURATION MODAL FORM -->
            <!-- /.modal -->
            <!-- end: SPANEL CONFIGURATION MODAL FORM -->
            <div class="container">
                <!-- start: PAGE HEADER -->

                <!-- end: PAGE HEADER -->
                <!-- start: PAGE CONTENT -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="panel">

                            <div class="panel-body">






                                <h2><?php echo "Edit User"; ?></h2>
                                <hr>


                                <div id="result">


                                </div>

                                <div class="form-group">

                                    <label class="col-sm-4 control-label" for="group-name">
                                        Name
                                    </label>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <input type='hidden' id='usr_id'  name='user_id' value='<?php echo $_SESSION['resultarray'][0]['user_id'] ?>'>
                                            <input type="text"  value='<?php echo $_SESSION['resultarray'][0]['name'] ?>' name="name" id="name" class="form-control required">
                                            <label id="error_name" style="color: red;display:none">Name is Missing</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-4 control-label" for="group-name">
                                        Username
                                    </label>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <input type="text" readonly name="username" value='<?php echo $_SESSION['resultarray'][0]['login_id'] ?>' id="username" class="form-control required" value="">
                                            <label id="error_username" style="color: red;display:none">Username is Missing</label>
                                            <label id="exist_username"></label>
                                        </div>
                                    </div>
                                </div>


                                <div class="form-group">
                                    <label class="col-sm-4 control-label" for="group-name">
                                        password
                                    </label>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <input type="password" name="password" id="password" class="form-control" value=""> 
                                            <label id="error_password" style="color: red;display:none">Password is Missing</label>

                                        </div>
                                    </div>
                                </div>


                                <div class="form-group">
                                    <label class="col-sm-4 control-label" for="group-name">
                                        Status
                                    </label>
                                    <div class="col-sm-6">
                                        <select id ="status">
                                            <option value="1" selected="selected">Active</option>
                                            <option value="0">InActive</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label class="col-sm-4 control-label" for="crete">
                                        </label>
                                        <div class="col-sm-6">
                                            <div class="form-group">

                                                <button id="cancel" type="button" class="btn btn-default">
                                                    Reset <i class="icon-circle-arrow-cross"></i>
                                                </button>
                                                <button type="submit" name="edituser" id="edituser" class="btn btn-primary">
                                                    Save <i class="icon-circle-arrow-right"></i>
                                                </button></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
include_once './includes/footer.php';
?>
