<?php
ob_start();
session_start();

include_once './includes/session.php';

include_once './includes/header.php';
$title = "LSF | Legal Aid";
$pageContents = ob_get_contents ();
$activePage = '';
ob_end_clean (); 
echo str_replace ('<!--TITLE-->', $title, $pageContents);
?>
<div class="navbar-tools">
                      <?php                        
                      include_once './includes/top.php';
                      ?>
                    </div>
                    </div>    
                </div>
             <div class="main-container">
                <div class="navbar-content">
                    <!-- start: SIDEBAR -->
                    <div class="main-navigation navbar-collapse collapse">
                        <!-- start: MAIN MENU TOGGLER BUTTON -->
                        <div class="navigation-toggler">
                            <i class="clip-chevron-left"></i>
                            <i class="clip-chevron-right"></i>
                        </div>
                        <?php include('./includes/menu.php'); ?>
                    </div>
                </div>
             <div class="main-content">
                    <div class="container">
                        <!-- start: PAGE HEADER -->
                        <div class="row">               
                               <div id="outgoing"> 
                               </div>
                            <div id="incoming"> 
                               </div>
                         </div>
                        <div class="row">
                        <div class="col-sm-12">
                            <!-- start: DATE/TIME PICKER PANEL -->
                            <div class="panel">
                                <div class="panel-body">
                                    <label class="heading"> Legal Aid - Delayed</label>
                                   <div style="display: inline; float: right;" class="form-group tooltip-top">
                                        <table class="downloadbutton">
                                        <tr> 
                                            
                                            <td>
                                        <form action="download.php" method="POST">
                                            <input type="hidden" name="report" value="Legal-Aid-Delayed"/>
                                            <select name="export" style="size:13px;font-size:13px;">
                                                <option value="0" style="font-size:13px">Select An Option</option>
                                                <option value="export" style="font-size:13px">Excel</option>
                                                <option value="exportpdf" style="font-size:13px">PDF</option>
                                           </select>
                                           <input type="submit"    name="download" class="btn-primary" align="right" value="Download"/>
                                           </form>
                                   </td>
                                   <td>
                                   </td>
                                   </tr>
                                   </table>
                                    </div>
                                    
                                    </div>
                                <!-- end: DATE/TIME PICKER PANEL -->
                            </div>
                        </div>
                    </div>
<div class="row nonajax">
   <table data-toggle="table" data-url="reportservice.php/?action=delayed&source="  data-show-refresh="true" data-show-toggle="false" data-show-columns="false" data-search="true" data-select-item-name="toolbar1" data-pagination="true" data-sort-name="name" data-sort-order="desc" >
                <thead>
                    <tr>
                        
                        <th data-field="Submitted" data-sortable="true">Submitted on</th>
                        <th data-field="accepted_at" data-sortable="true">Accepted on</th>
                        <th data-field="phone_number" data-sortable="true">Mobile</th>
                        <th data-field="name" data-sortable="true">Submitted By</th>
                        <th data-field="unit_name" data-sortable="true">Unit</th>
                        <th data-field="gender" data-sortable="true">Gender</th>
                        <th data-field="education" data-sortable="true">Education</th>
                        <th data-field="age" data-sortable="true">Age</th>
                        <th data-field="marital_status">Marital Status</th>
                        <th data-field="case_type" data-sortable="true">Case Type</th>
                        <th data-field="case_status" data-sortable="true">Status</th>
                        
                    </tr>
                    </thead>
                </table>
</div>

                        
                        
                        
                        
                        
                </div>
             </div>
<?php
include_once './includes/footer.php';
?>