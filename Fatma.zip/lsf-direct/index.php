<?php
ob_start();
session_start();
if (isset($_SESSION['Name'])) {
    header('Location:dashboard.php');
    exit;
    $hinr = "";
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />
        <title></title>

        <link rel="stylesheet" type="text/css" href="assetsv2/css/style.css" media="all" />


 <!--<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.6/jquery-ui.min.js"></script>-->
        <script type="text/javascript" src="assetsv2/js/jquery.inputfocus-0.9.min.js"></script>
        <script type="text/javascript" src="assetsv2/js/jquery.main.js"></script>
    </head>
    <body>


        <div id="container">
            <form action="processlogin.php" method="post">

                <!-- #first_step -->
                <div>
                    <h1 id="login_header">WELCOME TO <span>LSF</span> PLATFORM</h1>                 
                           <img src="assetsv2/image/logoLSF.png" alt="lsf logo" class="login_form_logo"/>
                    <div class="form_1">
                        <input type="text" name="uname" id="username" placeholder="username" />
<!--                        <label for="username">Your Login Username</label>-->

                        <input type="password" name="pass" id="password" placeholder="password" />
                        <!--<label for="password">Your Login Password</label>-->

                    </div>      <!-- clearfix --><div class="clear"></div><!-- /clearfix -->
<!--                    <input class="submit" type="submit" name="login" id="submit_fourth" value=""/>-->
                    <a href="#" class="forgot_pass">Forgot Password?</a>
                    </div>      <!-- clearfix --><div class="clear"></div>
                    <button type="submit" name="login" class="btn btn-danger" id="submit_first" value="">
                        Login 
                    </button>
                </div>      <!-- clearfix --><div class="clear"></div><!-- /clearfix -->



            </form>
        </div>
        <script src="assets/js/jquery-2.1.0.min.js"></script>
        <script src="assets/plugins/jquery-ui/jquery-ui-1.10.2.custom.min.js"></script>
        <script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
        <script src="assets/plugins/blockUI/jquery.blockUI.js"></script>
        <script src="assets/plugins/iCheck/jquery.icheck.min.js"></script>
        <script src="assets/plugins/perfect-scrollbar/src/jquery.mousewheel.js"></script>
        <script src="assets/plugins/perfect-scrollbar/src/perfect-scrollbar.js"></script>
        <script src="assets/js/main.js"></script>
        <!-- end: MAIN JAVASCRIPTS -->
        <!-- start: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
        <script src="assets/plugins/jquery-validation/dist/jquery.validate.min.js"></script>
        <script src="assets/js/login.js"></script>
        <!-- end: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
        <script>
            jQuery(document).ready(function () {
                Main.init();
                Login.init();
            });
        </script>
    </body>
</html>
<?php ob_flush(); ?>