<!-- Collect the nav links, forms, and other content for toggling -->
<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">

    <ul class="nav navbar-nav navbar-right">
<li id="collapsemenu" style="padding-top: 9px;margin-right: 12px;display: none">
    <div class="dropdown">
  <button class="btn btn-default dropdown-toggle btn-danger" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
    <span class="glyphicon glyphicon-list"></span>
    <span class="caret"></span>
  </button>
  <ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
    <li><a href="dashboard">Dashboard</a></li>
    <li role="separator" class="divider"></li>
    <li><a href="reports">Reports</a></li>
    <li role="separator" class="divider"></li>
    <li><a href="legaleducation">Legal Education</a></li>
    <li role="separator" class="divider"></li>
    <li><a href="legalaid">Legal Aid</a></li>
    <li role="separator" class="divider"></li>
    
  </ul>
</div>
         <!--<button class="btn btn-success" ><span class="glyphicon glyphicon-list"></span></button>-->
        </li>        
        <li>
            <?php
            include_once './includes/top.php';
            ?> 
        </li>
    </ul>
</div><!-- /.navbar-collapse -->
</div><!-- /.container-fluid -->
</nav>
<br><br/><br><br/>
<!-- BOTTOM BAR-->
<!--<div class="row navbar-fixed-top" id="position_bottom_bar">-->  
<div class="row navbar-fixed-top" id="position_bottom_bar">
    <div class="col-xs-12 col-sm-6 col-md-2">

        <div class="col-xs-6 col-md-8" id="image_logo">
            <a href="#" class="thumbnail">
                <img src="assetsv2/image/logoLSF.png" alt="" id="positionLogo"/>
                <br/>
            </a>
        </div>

    </div>

</div>
<body id="body_bg">

<!-- BOTTOM BAR-->