<?php

echo "<ul class=\"main-navigation-menu\">";

// Dashboard
echo "<li";
if ($activePage == 'dashboard') {
    echo " class=\"active\" ";
}
echo ">";
echo "<a href = \"dashboard\"><i class=\"clip-home-3\"></i>" .
 "<span class=\"title\">Dashbaord</span>" .
 "<span class=\"selected\"></span>" .
 "</a>" .
 "</li>";

echo "<li";
if ($activePage == 'reports-pending'||$activePage=="reports-declined"||$activePage=="reports") {
    echo " class=\"active\" ";
}
echo ">";
echo "<a href = \"javascript:void(0)\"><i class = \"icon-book\"></i>" .
 "<span class = \"title\">Reports" .
 "</span><i class=\"icon-angle-down\"></i>" .
 "<span class=\"title\"></span>" .
 "</a>";
// Address book submenu create new
echo "<ul class = \"sub-menu\">" .
 "<li>" .
 "<a href = \"reports\">" .
 "<span class = \"title\">Reports" .
 "</span>" .
 "</a>" .
 "</li>" .
        "<li>" .
 "<a href = \"LegalAid-Delayed\">" .
 "<span class = \"title\">LegalAid-Delayed-Accepted" .
 "</span>" .
 "</a>" .
 "</li>". 
        "<li>" .
 "<a href = \"LegalEducation-Delayed\">" .
 "<span class = \"title\">LegalEducation-Delayed-Accepted" .
 "</span>" .
 "</a>" .
 "</li>". 
        "</ul>";
        
if($_SESSION['type']=="super admin"){
echo "<li";
if($activePage=='paralegal'){
      echo " class=\"active  mainmenu\" ";
}
echo ">";
echo "<a href=\"paralegal\"><i class=\"clip-data\"></i>" .
 "<span class=\"title\">Paralegal</span>" .
 "<span class=\"selected\"></span>" .
 "</a>" .
 "</li>";

}

echo "<li" ;
if ($activePage == 'legaleducation') {
    echo " class=\"active\"";
}
echo  ">";
echo "<a href=\"legaleducation\"><i class=\"clip-book\"></i>" .
 "<span class=\"title\">Legal Education</span>" .
 "<span class=\"selected\"></span>" .
 "</a>" .
 "</li>";



echo "<li" ;
if ($activePage == 'aid') {
    echo " class=\"active\"";
}
echo  ">";
echo "<a href=\"legalaid\"><i class=\"clip-book\"></i>" .
 "<span class=\"title\">Legal Aid</span>" .
 "<span class=\"selected\"></span>" .
 "</a>" .
 "</li>";


echo "</ul>";


?>
