<div class="row" style="margin-left: 10%; padding-bottom: 30px;">
                        
                           <div id='cssmenu'>
<ul>
   <li><a href='dashboard'>Dashboard</a></li>
   <li><a href='reports'>Reports</a></li>
   <li class='active has-sub'><a href='#'>Paralegal</a>
      <ul>
        
         <li><a href='paralegal'>View</a></li>
         <li><a href='addparalegal'>Add</a></li>
      </ul>
       
   </li>
   <li><a href='legaleducation'>Legal Education</a></li>
         <li><a href='legalaid'>Legal Aid</a></li>
</ul>
</div>
                        
                            </div>         