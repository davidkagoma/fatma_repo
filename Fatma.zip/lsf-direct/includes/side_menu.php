<?php

echo '<nav id="menu" class="left">';
echo "<ul><li>";
echo "<a href=\"dashboard\"";
if ($activePage == 'dashboard') {
    echo " class=\"active\" ";
}
echo "><i class=\"fa fa-home\"></i>" .
 "Dashbaord" .
 "" .
 "</a>" .
 "</li>";

echo "<li>";

echo "<a href = \"reports\"";
if ($activePage == "reports") {
    echo " class=\"active\" ";
}
echo"><i class=\"fa fa-files-o\"></i>
" .
 "Reports" .
 "</a></li>";
echo "<li>";


echo "<a href = \"javascript:void(0)\" ";
if ($activePage == 'paralegal') {
    echo "class=\"active\" ";
}
echo "><i class=\"clip-users\"></i></i>" .
 "Paralegal <i class=\"fa fa-caret-down\"></i>" .
 "</a>" .
 "<ul>";
if ($_SESSION['type'] == "super admin") {
    echo "<li><a href = \"paralegal\">" .
    "View Paralegals" .
    "</a>" . "</li>";
}

if ($_SESSION['type'] == "super admin") {
    echo "<li>" .
    '<a href="add_Punits">' .
    'Add Paralegal Units' .
    "</a>" .
    " </li>";
}
if ($_SESSION['type'] == "Paralegal Admin" || $_SESSION['type'] == "super admin") {
    echo '<li>' .
    '<a href="addparalegal">' .
    'Add Paralegals' .
    '</a>' .
    '</li>';
}
if ($_SESSION['type'] == "Paralegal Admin") {
    echo "<li><a href = \"paralegal\">" .
    "View Paralegals" .
    "</a>" . "</li>";
}

echo "<li><a href = \"reports-Paralegal-Perfromence\">" .
 "Paralegal Performance" .
 "</a>"
 . "</li>"
 . "</ul>" .
 "</li>";

//}
/* echo "<li" ;
  if ($activePage == 'users') {
  echo " class=\"active\"";
  }
  echo  ">";
  echo "<a href=\"users\"><i class=\"clip-users\"></i>" .
  "<span class=\"title\">Users</span>" .
  "<span class=\"selected\"></span>" .
  "</a>" .
  "</li>";

 */

echo "<li>";

echo "<a href = \"legaleducation\"";
if ($activePage == "legaleducation") {
    echo " class=\"active\" ";
}
echo"><i class=\"icon-book\"></i>
" .
 "Legal Education" .
 "</a></li>";

echo "<li>";

echo "<a href = \"legalaid\"";
if ($activePage == "legalaid") {
    echo " class=\"active\" ";
}
echo"><i class=\"fa fa-life-ring\"></i>
" .
 "Legal Aid" .
 "</a></li>";




echo "<li>";
echo "<a href = \"javascript:void(0)\"";
if ($activePage == 'smslog') {
    echo " class=\"active\" ";  
}
echo ">";
echo"<i class=\"glyphicon glyphicon-envelope\"></i>" .
 "SMS ";   
echo "<i class=\"fa fa-caret-down\"></i>" .
 "</a>" ;       

echo "<ul>" .
 "<li>" .
 "<a href = \"smslog\">" .
 "Logs" .
 "</a>" .
 "</li>" .
 "<li>" .
 "<a href = \"schedules\">" .
"Schedule" . 
 "</a>" .
 "</li>" .
 "</ul></li>" .
 "</nav>";
?>
