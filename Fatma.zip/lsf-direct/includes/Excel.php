<?php 
require_once "./includes/libraries/PHPExcel.php";
class excel extends PHPExcel {
    public function __construct() {
        parent::__construct();
    }

}

