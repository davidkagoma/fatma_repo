<div class="dropdown" id="user_menu">
    <button class="btn btn-danger dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
        <?php echo $_SESSION['Name']; ?>
        <span class="caret"></span>
    </button>
    <ul class="dropdown-menu" aria-labelledby="dropdownMenuDivider">
        <li>
            <a href="profile">
                <span class="glyphicon glyphicon-user" aria-hidden="true"></span>           
                <?php echo 'Profile'; ?>
            </a>
        </li>
        <?php
        if($_SESSION['Name']=='Administrator'){
        ?>
        <li>
            <a href="users">
                <span class="clip-users" aria-hidden="true"></span>           
                <?php echo 'Users'; ?>
            </a>
        </li>
        <?php }?>
 <li role="separator" class="divider">
        <li>
            <a href="logout">
                <span class="glyphicon glyphicon-off" aria-hidden="true"></span>  
                &nbsp;<?php echo 'Logout'; ?>
            </a>
        </li>

    </ul>
</div>