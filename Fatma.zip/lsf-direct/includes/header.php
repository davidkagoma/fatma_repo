<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        <title>LSF</title>
        <!-- end: META -->
        <!-- v2 styles-->
        <link href="assetsv2/css/lsfStyle.css" rel="stylesheet" media="screen">
        <link rel="stylesheet" href="http://netdna.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
        <link href="assetsv2/css/side_menu_style.css" rel="stylesheet" media="screen">
        <!-- v2 styles-->
        <!-- start: MAIN CSS -->
        <link href="assetsv2/css/bootstrap.min.css" rel="stylesheet" media="screen">
        <link rel="stylesheet" href="assets/plugins/font-awesome/css/font-awesome.min.css">
                <link rel="stylesheet" href="assets/fonts/style.css"><!--
-->                <link rel="stylesheet" href="assets/css/main.css"><!--
                <link rel="stylesheet" href="assets/css/main-responsive.css">
                <link rel="stylesheet" href="assets/plugins/iCheck/skins/all.css">
                <link rel="stylesheet" href="assets/plugins/perfect-scrollbar/src/perfect-scrollbar.css">
                <link rel="stylesheet" href="assets/css/bootstrap-table.css">
                <link rel="stylesheet" href="assets/css/theme_light.css" id="skin_color">
                <link rel="stylesheet" href="assets/menu/styles.css">-->
        <!--[if IE 7]>
        <link rel="stylesheet" href="assets/plugins/font-awesome/css/font-awesome-ie7.min.css">
        <![endif]-->
        <!-- end: MAIN CSS -->
        <!-- start: CSS REQUIRED FOR THIS PAGE ONLY -->
        <!-- end: CSS REQUIRED FOR THIS PAGE ONLY -->
<!-- <script>       
     jQuery(document).ready(function() {
      $('#myModal').on('shown.bs.modal', function () {
     $('#myInput').focus()
     })
     }
                </script>-->
        <script>var unit =''; var org = '';</script>
    </head>
    <body ><!--class="footer-fixed"-->
        <!-- start: HEADER -->
        <!--    <div class="panel panel-default navbar-fixed-top" id="style_top_header"> navbar-fixed-top
                <div class="panel-body">
                    <br>
                     SET HEADER CONTENTS 
                    <div class="row">
                        <div class="col-xs-12 col-sm-6 col-md-2" >
                                <img src="assets/images/logoLSF.png" id='logo' alt='test'/>  
                        </div>-->
        <nav class="navbar navbar-inverse navbar-fixed-top" id="top_uper_header">
            <div class="container-fluid">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header" >
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                   
                </div>

               


