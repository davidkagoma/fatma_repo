<?php

echo "<ul class=\"main-navigation-menu\">";

// Dashboard
echo "<li";
if ($activePage == 'dashboard') {
    echo " class=\"active\" ";
}
echo ">";
echo "<a href=\"dashboard\"><i class=\"clip-home-3\"></i>" .
 "<span class=\"title\">Dashbaord</span>" .
 "<span class=\"selected\"></span>" .
 "</a>" .
 "</li>";

echo "<li";
if ($activePage=="reports") {
    echo " class=\"active\" ";
}
echo ">";
echo "<a href = \"reports\"><i class = \"icon-book\"></i>" .
 "<span class = \"title\">Reports" .
 "</span></i>" .
 "<span class=\"title\"></span>" .
 "</a>";
// Address book submenu create new


/*echo "<li";
if ($activePage == 'reports') {
    echo " class=\"active\" ";
}
echo ">"
echo "<a href=\"reports\"><i class=\"clip-attachment\"></i>" .
 "<span class=\"title\">Reports</span>" .
 "<span class=\"selected\"></span>" .
 "</a>" .
 "</li>";*/

//if($_SESSION['loginid']==1){
echo "<li";
if($activePage=='paralegal'){
      echo " class=\"active  mainmenu\" ";
}
echo ">";
echo "<a href=\"paralegal\"><i class=\"clip-data\"></i>" .
 "<span class=\"title\">Paralegal</span>" .
 "<span class=\"selected\"></span>" .
 "</a>" .
 "</li>";

//}
/*echo "<li" ;
if ($activePage == 'users') {
    echo " class=\"active\"";
}
echo  ">";
echo "<a href=\"users\"><i class=\"clip-users\"></i>" .
 "<span class=\"title\">Users</span>" .
 "<span class=\"selected\"></span>" .
 "</a>" .
 "</li>";

*/



echo "<li";
if ($activePage == 'legaleducation'||$activePage=="legaleducationaccepted"||$activePage=="legaleducationdeclined") {
    echo " class=\"active\" ";
}
echo ">";
echo "<a href = \"javascript:void(0)\"><i class = \"icon-book\"></i>" .
 "<span class = \"title\">Legal Education" .
 "</span><i class=\"icon-angle-down\"></i>" .
 "<span class=\"title\"></span>" .
 "</a>";
// Address book submenu create new
echo "<ul class = \"sub-menu\">" .
 "<li>" .
 "<a href = \"legaleducation\">" .
 "<span class = \"title\">Pending" .
 "</span>" .
 "</a>" .
 "</li>" .
        "<li>" .
 "<a href = \"legaleducationaccepted\">" .
 "<span class = \"title\">Accepted" .
 "</span>" .
 "</a>" .
 "</li>" .
"<li>" .
 "<a href = \"LegalEducation-Delayed\">" .
 "<span class = \"title\">Delayed-Accpeted" .
 "</span>" .
 "</a>" .
 "</li>" .
        
        "<li>" .
 "<a href = \"legaleducationdeclined\">" .
 "<span class = \"title\">Declined" .
 "</span>" .
 "</a>" .
 "</li>" .
 "<li>".
"</ul>" .
 "</li>";




echo "<li";
if ($activePage == 'aid'||$activePage=="aidaccepted"||$activePage=="aiddeclined") {
    echo " class=\"active\" ";
}
echo ">";
echo "<a href = \"javascript:void(0)\"><i class = \"icon-book\"></i>" .
 "<span class = \"title\">Legal Aid" .
 "</span><i class=\"icon-angle-down\"></i>" .
 "<span class=\"title\"></span>" .
 "</a>";
// Address book submenu create new
echo "<ul class = \"sub-menu\">" .
 "<li>" .
 "<a href = \"legalaid\">" .
 "<span class = \"title\">Pending" .
 "</span>" .
 "</a>" .
 "</li>" .
        "<li>" .
 "<a href = \"legalaidaccepted\">" .
 "<span class = \"title\">Accepted" .
 "</span>" .
 "</a>" .
 "</li>" .
        "<li>" .
         "<li>" .
 "<a href = \"reports-Delayed\">" .
 "<span class = \"title\">Accepted-Delayed" .
 "</span>" .
 "</a>" .
 "</li>" .
        "<li>" .
 "<a href = \"legalaiddeclined\">" .
 "<span class = \"title\">Declined" .
 "</span>" .
 "</a>" .
 "</li>" .
 "<li>".
"</ul>" .
 "</li>";







echo "</ul>";


?>
