<?php

include_once 'query.php';
$query = new query();
if(isset($_REQUEST)){
    if($_REQUEST['action']=='view'){
$sql = "SELECT * FROM legal_education_direct";

$result = $query ::select($sql);
$resultarray = array();
while($row = mysql_fetch_array($result)){
    
    $resultarray[] = $row;
    
}
echo json_encode($resultarray);
    }

}
