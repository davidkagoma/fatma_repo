<?php
ob_start();
session_start();

include_once './includes/session.php';

include_once './includes/header.php';
$title = "LSF | LegalEducation";
$pageContents = ob_get_contents ();
$activePage = 'legaleducation';
ob_end_clean (); 
echo str_replace ('<!--TITLE-->', $title, $pageContents);
?>
<div class="navbar-tools">
                      <?php                        
                      include_once './includes/top.php';
                      ?>
                    </div>
                    </div>    
                </div>
             <div class="main-container">
                <div class="navbar-content">
                    <!-- start: SIDEBAR -->
                    <div class="main-navigation navbar-collapse collapse">
                        <!-- start: MAIN MENU TOGGLER BUTTON -->
                        <div class="navigation-toggler">
                            <i class="clip-chevron-left"></i>
                            <i class="clip-chevron-right"></i>
                        </div>
                        
                        <?php include('includes/menu.php'); ?>
                    </div>
                   
                </div>
             
                
                <div class="main-content">
                    <div class="container">
                        <!-- start: PAGE HEADER -->
                        <div class="row">
                            <div class="col-sm-12">
                                <ol class="breadcrumb">
                                 <li>
                                 <a href="#">
                                 </a>
                                 </li>
                                 </ol>
                               
                                </div>
                               <div id="outgoing"> 
                               </div>
                            
                            
                            <div id="incoming"> 
                               </div>
                         </div>
                        
                        
                        
                        
                    <div class="row">
                        <div class="col-sm-12">
                            <!-- start: DATE/TIME PICKER PANEL -->
                            <div class="panel">
                                <div class="panel-body">

                                    <div style="display: inline;width: 100px; font-size:30px;">Legal Education</div>
                                    
                                    
                                    
                                </div>
                                <!-- end: DATE/TIME PICKER PANEL -->
                            </div>
                        </div>
                    </div>
<div class="row nonajax">
   <table data-toggle="table" data-url="reportservice.php/?action=viewgenderbaseeducation&gender=Male"  data-show-refresh="true" data-show-toggle="false" data-show-columns="false" data-search="true" data-select-item-name="toolbar1" data-pagination="true" data-sort-name="name" data-sort-order="desc" >
                    <thead>
                    <tr>
                        <th data-field="timestamp" data-sortable="true">Submission Date </th>
                        <th data-field="mobile_no" data-sortable="true">Mobile</th>
                        <th data-field="date" data-sortable="true">Date of Training</th>
                        <th data-field="event_type" data-sortable="true">Event Type</th>
                        <th data-field="topic_discussed" data-sortable="true">Topic</th>
                        <th data-field="village_location" data-sortable="true">Village</th>
  
                        <th data-field="duration" data-sortable="true">Duration</th>
                    </tr>
                    </thead>
                </table>
</div>
                        
                        
                        
                        
                        
                </div>
             </div>
<?php
include_once './includes/footer.php';
?>