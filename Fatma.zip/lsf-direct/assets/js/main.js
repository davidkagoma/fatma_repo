// global variables
var isIE8 = false;
var isIE9 = false;
var $windowWidth;
var $windowHeight;
var $pageArea;
//Main Function
var Main = function () {
   //function to detect explorer browser and its version
    var runInit = function () {
        if (/MSIE (\d+\.\d+);/.test(navigator.userAgent)) {
            var ieversion = new Number(RegExp.$1);
            if (ieversion == 8) {
                isIE8 = true;
            } else if (ieversion == 9) {
                isIE9 = true;
            }
        }
    };
    //function to adjust the template elements based on the window size
    var runElementsPosition = function () {
        $windowWidth = $(window).width();
        $windowHeight = $(window).height();
        $pageArea = $(window).height() - $('header').outerHeight() - $('.footer').outerHeight();
        $('.sidebar-search input').removeAttr('style').removeClass('open');
        $('.sidebar-fixed .wrap-menu').css('height', $pageArea);
        runContainerHeight();
    };
    //function to adapt the Main Content height to the Main Navigation height 
    var runContainerHeight = function () {
        mainContainer = $('.main-content > .container');
        mainNavigation = $('.main-navigation');
        if (mainContainer.outerHeight() < mainNavigation.outerHeight()) {
            mainContainer.css('min-height', mainNavigation.outerHeight());
        } else {
            mainContainer.css('min-height', '760px');
        };
    };
    //function to activate the ToDo list, if present 
    var runToDoAction = function () {
        if ($(".todo-actions").length) {
            $(".todo-actions").click(function () {
                if ($(this).find("i").attr("class") == "icon-check-empty") {
                    $(this).find("i").removeClass("icon-check-empty").addClass("icon-check");
                    $(this).parent().find("span").css({
                        opacity: .25
                    });
                    $(this).parent().find(".desc").css("text-decoration", "line-through");
                } else {
                    $(this).find("i").removeClass("icon-check").addClass("icon-check-empty");
                    $(this).parent().find("span").css({
                        opacity: 1
                    });
                    $(this).parent().find(".desc").css("text-decoration", "none");
                }
                return !1;
            });
        }
    };
    //function to activate the Tooltips, if present 
    var runTooltips = function () {
        if ($(".tooltips").length) {
            $('.tooltips').tooltip();
        }
    };
    //function to activate the Popovers, if present 
    var runPopovers = function () {
        if ($(".popovers").length) {
            $('.popovers').popover();
        }
    };
    //function to allow a button or a link to open a tab
    var runShowTab = function () {
        if ($(".show-tab").length) {
            $('.show-tab').bind('click', function (e) {
                e.preventDefault();
                var tabToShow = $(this).attr("href");
                if ($(tabToShow).length) {
                    $('a[href="' + tabToShow + '"]').tab('show');
                }
            });
        };
        if (getParameterByName('tabId').length) {
            $('a[href="#' + getParameterByName('tabId') + '"]').tab('show');
        }
    };
    //function to extend the default settings of the Accordion
    var runAccordionFeatures = function () {
        if ($('.accordion').length) {
            $('.accordion .panel-collapse').each(function () {
                if (!$(this).hasClass('in')) {
                    $(this).prev('.panel-heading').find('.accordion-toggle').addClass('collapsed');
                }
            });
        }
        $(".accordion").collapse().height('auto');
        var lastClicked;
        
        $('.accordion .accordion-toggle').bind('click', function () {
            currentTab = $(this);
            $('html,body').animate({
                scrollTop: currentTab.offset().top - 100
            }, 1000);
        });
    };
    //function to reduce the size of the Main Menu
    var runNavigationToggler = function () {
        $('.navigation-toggler').bind('click', function () {
            if (!$('body').hasClass('navigation-small')) {
                $('body').addClass('navigation-small');
            } else {
                $('body').removeClass('navigation-small');
            };
        });
    };
    //function to activate the panel tools
    var runModuleTools = function () {
        $('.panel-tools .panel-expand').bind('click', function (e) {
            $('.panel-tools a').not(this).hide();
            $('body').append('<div class="full-white-backdrop"></div>');
            $('.main-container').removeAttr('style');
            backdrop = $('.full-white-backdrop');
            wbox = $(this).parents('.panel');
            wbox.removeAttr('style');
            if (wbox.hasClass('panel-full-screen')) {
                backdrop.fadeIn(200, function () {
                    $('.panel-tools a').show();
                    wbox.removeClass('panel-full-screen');
                    backdrop.fadeOut(200, function () {
                        backdrop.remove();
                    });
                });
            } else {
                $('body').append('<div class="full-white-backdrop"></div>');
                backdrop.fadeIn(200, function () {
                    $('.main-container').css({
                        'max-height': $(window).outerHeight() - $('header').outerHeight() - $('.footer').outerHeight() - 100,
                        'overflow': 'hidden'
                    });
                    backdrop.fadeOut(200);
                    backdrop.remove();
                    wbox.addClass('panel-full-screen').css({
                        'max-height': $(window).height(),
                        'overflow': 'auto'
                    });;
                });
            }
        });
        $('.panel-tools .panel-close').bind('click', function (e) {
            $(this).parents(".panel").remove();
            e.preventDefault();
        });
        $('.panel-tools .panel-refresh').bind('click', function (e) {
            var el = $(this).parents(".panel");
            el.block({
                overlayCSS: {
                    backgroundColor: '#fff'
                },
                message: '<img src="assets/images/loading.gif" /> Just a moment...',
                css: {
                    border: 'none',
                    color: '#333',
                    background: 'none'
                }
            });
            window.setTimeout(function () {
                el.unblock();
            }, 1000);
            e.preventDefault();
        });
        $('.panel-tools .panel-collapse').bind('click', function (e) {
            e.preventDefault();
            var el = jQuery(this).parent().closest(".panel").children(".panel-body");
            if ($(this).hasClass("collapses")) {
                $(this).addClass("expand").removeClass("collapses");
                el.slideUp(200);
            } else {
                $(this).addClass("collapses").removeClass("expand");
                el.slideDown(200);
            }
        });
    };
   //function to activate the 3rd and 4th level menus
    var runNavigationMenu = function () {
        $('.main-navigation-menu li.active').addClass('open');
        $('.main-navigation-menu > li a').bind('click', function () {
            if ($(this).parent().children('ul').hasClass('sub-menu') && (!$('body').hasClass('navigation-small') || !$(this).parent().parent().hasClass('main-navigation-menu'))) {
                if (!$(this).parent().hasClass('open')) {
                    $(this).parent().addClass('open');
                    $(this).parent().parent().children('li.open').not($(this).parent()).not($('.main-navigation-menu > li.active')).removeClass('open').children('ul').slideUp(200);
                    $(this).parent().children('ul').slideDown(200, function () {
                        runContainerHeight();
                    });
                } else {
                    if (!$(this).parent().hasClass('active')) {
                        $(this).parent().parent().children('li.open').not($('.main-navigation-menu > li.active')).removeClass('open').children('ul').slideUp(200, function () {
                            runContainerHeight();
                        });
                    } else {
                        $(this).parent().parent().children('li.open').removeClass('open').children('ul').slideUp(200, function () {
                            runContainerHeight();
                        });
                    }
                }
            }
        });
    };
    //function to activate the Go-Top button
    var runGoTop = function () {
        $('.go-top').bind('click', function (e) {
            $("html, body").animate({
                scrollTop: 0
            }, "slow");
            e.preventDefault();
        });
    };
    //function to avoid closing the dropdown on click 
    var runDropdownEnduring = function () {
        if ($('.dropdown-menu.dropdown-enduring').length) {
            $('.dropdown-menu.dropdown-enduring').click(function (event) {
                event.stopPropagation();
            });
        }
    };
    //function to return the querystring parameter with a given name.
    var getParameterByName = function (name) {
        name = name.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]");
        var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
            results = regex.exec(location.search);
        return results == null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
    };
    //function to activate the iCheck Plugin 
    var runCustomCheck = function () {
        if ($('input[type="checkbox"]').length || $('input[type="radio"]').length) {
            $('input[type="checkbox"].grey, input[type="radio"].grey').iCheck({
                checkboxClass: 'icheckbox_minimal-grey',
                radioClass: 'iradio_minimal-grey',
                increaseArea: '10%' // optional
            });
            $('input[type="checkbox"].red, input[type="radio"].red').iCheck({
                checkboxClass: 'icheckbox_minimal-red',
                radioClass: 'iradio_minimal-red',
                increaseArea: '10%' // optional
            });
            $('input[type="checkbox"].green, input[type="radio"].green').iCheck({
                checkboxClass: 'icheckbox_minimal-green',
                radioClass: 'iradio_minimal-green',
                increaseArea: '10%' // optional
            });
            $('input[type="checkbox"].teal, input[type="radio"].teal').iCheck({
                checkboxClass: 'icheckbox_minimal-aero',
                radioClass: 'iradio_minimal-aero',
                increaseArea: '10%' // optional
            });
            $('input[type="checkbox"].orange, input[type="radio"].orange').iCheck({
                checkboxClass: 'icheckbox_minimal-orange',
                radioClass: 'iradio_minimal-orange',
                increaseArea: '10%' // optional
            });
            $('input[type="checkbox"].purple, input[type="radio"].purple').iCheck({
                checkboxClass: 'icheckbox_minimal-purple',
                radioClass: 'iradio_minimal-purple',
                increaseArea: '10%' // optional
            });
            $('input[type="checkbox"].yellow, input[type="radio"].yellow').iCheck({
                checkboxClass: 'icheckbox_minimal-yellow',
                radioClass: 'iradio_minimal-yellow',
                increaseArea: '10%' // optional
            });
            $('input[type="checkbox"].square-black, input[type="radio"].square-black').iCheck({
                checkboxClass: 'icheckbox_square',
                radioClass: 'iradio_square',
                increaseArea: '10%' // optional
            });
            $('input[type="checkbox"].square-grey, input[type="radio"].square-grey').iCheck({
                checkboxClass: 'icheckbox_square-grey',
                radioClass: 'iradio_square-grey',
                increaseArea: '10%' // optional
            });
            $('input[type="checkbox"].square-red, input[type="radio"].square-red').iCheck({
                checkboxClass: 'icheckbox_square-red',
                radioClass: 'iradio_square-red',
                increaseArea: '10%' // optional
            });
            $('input[type="checkbox"].square-green, input[type="radio"].square-green').iCheck({
                checkboxClass: 'icheckbox_square-green',
                radioClass: 'iradio_square-green',
                increaseArea: '10%' // optional
            });
            $('input[type="checkbox"].square-teal, input[type="radio"].square-teal').iCheck({
                checkboxClass: 'icheckbox_square-aero',
                radioClass: 'iradio_square-aero',
                increaseArea: '10%' // optional
            });
            $('input[type="checkbox"].square-orange, input[type="radio"].square-orange').iCheck({
                checkboxClass: 'icheckbox_square-orange',
                radioClass: 'iradio_square-orange',
                increaseArea: '10%' // optional
            });
            $('input[type="checkbox"].square-purple, input[type="radio"].square-purple').iCheck({
                checkboxClass: 'icheckbox_square-purple',
                radioClass: 'iradio_square-purple',
                increaseArea: '10%' // optional
            });
            $('input[type="checkbox"].square-yellow, input[type="radio"].square-yellow').iCheck({
                checkboxClass: 'icheckbox_square-yellow',
                radioClass: 'iradio_square-yellow',
                increaseArea: '10%' // optional
            });
            $('input[type="checkbox"].flat-black, input[type="radio"].flat-black').iCheck({
                checkboxClass: 'icheckbox_flat',
                radioClass: 'iradio_flat',
                increaseArea: '10%' // optional
            });
            $('input[type="checkbox"].flat-grey, input[type="radio"].flat-grey').iCheck({
                checkboxClass: 'icheckbox_flat-grey',
                radioClass: 'iradio_flat-grey',
                increaseArea: '10%' // optional
            });
            $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
                checkboxClass: 'icheckbox_flat-red',
                radioClass: 'iradio_flat-red',
                increaseArea: '10%' // optional
            });
            $('input[type="checkbox"].flat-green, input[type="radio"].flat-green').iCheck({
                checkboxClass: 'icheckbox_flat-green',
                radioClass: 'iradio_flat-green',
                increaseArea: '10%' // optional
            });
            $('input[type="checkbox"].flat-teal, input[type="radio"].flat-teal').iCheck({
                checkboxClass: 'icheckbox_flat-aero',
                radioClass: 'iradio_flat-aero',
                increaseArea: '10%' // optional
            });
            $('input[type="checkbox"].flat-orange, input[type="radio"].flat-orange').iCheck({
                checkboxClass: 'icheckbox_flat-orange',
                radioClass: 'iradio_flat-orange',
                increaseArea: '10%' // optional
            });
            $('input[type="checkbox"].flat-purple, input[type="radio"].flat-purple').iCheck({
                checkboxClass: 'icheckbox_flat-purple',
                radioClass: 'iradio_flat-purple',
                increaseArea: '10%' // optional
            });
            $('input[type="checkbox"].flat-yellow, input[type="radio"].flat-yellow').iCheck({
                checkboxClass: 'icheckbox_flat-yellow',
                radioClass: 'iradio_flat-yellow',
                increaseArea: '10%' // optional
            });
        };
    };
    //Search Input function
    var runSearchInput = function () {
        var search_input = $('.sidebar-search input');
        var search_button = $('.sidebar-search button');
        var search_form = $('.sidebar-search');
        search_input.attr('data-default', $(search_input).outerWidth()).focus(function () {
            $(this).animate({
                width: 200
            }, 200);
        }).blur(function () {
            if ($(this).val() == "") {
                if ($(this).hasClass('open')) {
                    $(this).animate({
                        width: 0,
                        opacity: 0
                    }, 200, function () {
                        $(this).hide();
                    });
                } else {
                    $(this).animate({
                        width: $(this).attr('data-default')
                    }, 200);
                }
            }
        });
        search_button.bind('click', function () {
            if ($(search_input).is(':hidden')) {
                $(search_input).addClass('open').css({
                    width: 0,
                    opacity: 0
                }).show().animate({
                    width: 200,
                    opacity: 1
                }, 200).focus();
            } else if ($(search_input).hasClass('open') && $(search_input).val() == '') {
                $(search_input).removeClass('open').animate({
                    width: 0,
                    opacity: 0
                }, 200, function () {
                    $(this).hide();
                });
            } else if ($(search_input).val() != '') {
                return;
            } else $(search_input).focus();
            return false;
        });
    };
    //Set of functions for Style Selector
    var runStyleSelector = function () {
        $('#style_selector select').each(function () {
            $(this).find('option:first').attr('selected', 'selected');
        });
        $('.style-toggle').bind('click', function () {
            if ($(this).hasClass('open')) {
                $(this).removeClass('open').addClass('close');
                $('#style_selector_container').hide();
            } else {
                $(this).removeClass('close').addClass('open');
                $('#style_selector_container').show();
            }
        });
        setColorScheme();
        setLayoutStyle();
        setHeaderStyle();
        setFooterStyle();
        setBoxedBackgrounds();
    };
    $('.drop-down-wrapper').perfectScrollbar({
        wheelSpeed: 50,
        minScrollbarLength: 20,
        wheelPropagation: true
    });
    $('.navbar-tools .dropdown').on('shown.bs.dropdown', function () {
        $(this).find('.drop-down-wrapper').scrollTop(0).perfectScrollbar('update');
    });
    var setColorScheme = function () {
        $('.icons-color a').bind('click', function () {
            $('.icons-color img').each(function () {
                $(this).removeClass('active');
            });
            $(this).find('img').addClass('active');
            $('#skin_color').attr("href", "assets/css/theme_" + $(this).attr('id') + ".css");
        });
    };
    var setBoxedBackgrounds = function () {
        $('.boxed-patterns a').bind('click', function () {
            if ($('body').hasClass('layout-boxed')) {
                var classes = $('body').attr("class").split(" ").filter(function (item) {
                    return item.indexOf("bg_style_") === -1 ? item : "";
                });
                $('body').attr("class", classes.join(" "));
                $('.boxed-patterns img').each(function () {
                    $(this).removeClass('active');
                });
                $(this).find('img').addClass('active');
                $('body').addClass($(this).attr('id'));
            } else {
                alert('Select boxed layout');
            }
        });
    };
    var setLayoutStyle = function () {
        $('select[name="layout"]').change(function () {
            if ($('select[name="layout"] option:selected').val() == 'boxed')
                $('body').addClass('layout-boxed');
            else
                $('body').removeClass('layout-boxed');
        });
    };
    var setHeaderStyle = function () {
        $('select[name="header"]').change(function () {
            if ($('select[name="header"] option:selected').val() == 'default')
                $('body').addClass('header-default');
            else
                $('body').removeClass('header-default');
        });
    };
    var setFooterStyle = function () {
        $('select[name="footer"]').change(function () {
            if ($('select[name="footer"] option:selected').val() == 'fixed')
                $('body').addClass('footer-fixed');
            else
                $('body').removeClass('footer-fixed');
        });
    };
    var debounce = function (func, threshold, execAsap) {
        var timeout;
        return function debounced() {
            var obj = this,
                args = arguments;

            function delayed() {
                if (!execAsap)
                    func.apply(obj, args);
                timeout = null;
            };
            if (timeout)
                clearTimeout(timeout);
            else if (execAsap)
                func.apply(obj, args);
            timeout = setTimeout(delayed, threshold || 50);
        };
    };
    //Window Resize Function
    var runWIndowResize = function (func, threshold, execAsap) {
        //wait until the user is done resizing the window, then execute
        $(window).resize = debounce(function (e) {
            runElementsPosition();
        }, 50, false);
        $('.panel-scroll').perfectScrollbar({
            wheelSpeed: 50,
            minScrollbarLength: 20,
            wheelPropagation: true
        });
    };
    return {
        //main function to initiate template pages
        init: function () {
            runWIndowResize();
            runInit();
            runStyleSelector();
            runSearchInput();
            runElementsPosition();
            runToDoAction();
            runNavigationToggler();
            runNavigationMenu();
            runGoTop();
            runModuleTools();
            runDropdownEnduring();
            runTooltips();
            runPopovers();
            runShowTab();
            runAccordionFeatures();
            runCustomCheck();
        }
    };
}();

$('.required').focusout(function(){
   var id = $(this).attr("id");
   if($(this).val()==""){
   $("#error_"+id).show();
   }
});


$('.required').focus(function(){
   var id = $(this).attr("id");
   
   $("#error_"+id).hide();
   
});
$("#saveparalegal").click(function(){
    
    
    var error = false;
    $('.required').each(function(){
        var id = $(this).attr("id"); 
        if($(this).val()==""){
           error = true;
           $("#error_"+id).show();
           return ;
       } 
        
    });
    
	    

    if(!error){ 
       $.post('paralegalservice.php', {action:"save",name: $("#name").val(), age: $("#age").val(), address: $("#address").val(), region: $("#region").val(), district: $("#district").val(), village_area: $("#village").val(), phone_number: $("#mobile").val(),unit:$("#units").val(),username:$("#uname").val(),password:$("#password").val(),fname:$("#name").val(),type:$("#type").val()}, function (response) {
           $("#result").html('<div class="alert alert-success"><button type="button" class="close">×</button>'+response+'</div>');
           $(".alert").fadeTo(5000, 0).slideUp(500, function () {
         $(this).remove();
     });
           
           $(".required").val("");
            });
        
        
    }
});



function populateRegions(){
    var id = $("#zones").val();
    
    $.ajax({
    type: "POST",
    url: 'paralegalservice.php',
    data: {action:"getregions",id:id},
    dataType:'json',
    success: function(data) {

       var select = $("#region"), options = '';
       select.empty();      

       for(var i=0;i<data.length; i++)
       {
           if(region !=''){
               if(data[i].region_name == region){
               options += "<option selected = 'selected' value='"+data[i].id+"'>"+ data[i].region_name +"</option>";
           }
           else{
               options += "<option  value='"+data[i].id+"'>"+ data[i].region_name +"</option>";
           }
           }
           else{
        options += "<option value='"+data[i].id+"'>"+ data[i].region_name +"</option>";
    }              
       }

       select.append(options);
    }
    
    });
    
    $("#zones").change(function() {
        
         var id = $("#zones").val() ;
         
    $.ajax({
    type: "POST",
    url: 'paralegalservice.php',
    data: {action:"getregions",id:id},
    dataType:'json',
    success: function(data) {
       var select = $("#region"), options = '';
       select.empty();      

       for(var i=0;i<data.length; i++)
       {
        options += "<option value='"+data[i].id+"'>"+ data[i].region_name +"</option>";              
       }

       select.append(options);
    }
    
    
    
    
});
        
    });
   
    
    
    
}
function populateOrgainzation(){
    
$.ajax({
    type: "POST",
    url: 'paralegalservice',
    data: {action:"getOrganization"},
    dataType:'json',
     success: function(data) {
        
       var select = $("#organization"), options = '';
       select.empty();      
       if(window.location.href=="http://188.64.187.214/lsf-filter-new/add_Punits"){
            options = "<option selected='' value='0'>Selec An Organization</option>";
               options += "<option  value='-1'>New Organization</option>";
        }
        if(window.location.href=="http://188.64.187.214/lsf-filter-new/addparalegal"){
            options = "<option selected='' value='0'>Selec An Organization</option>";
        
        }
        
       for(var i=0;i<data.length; i++)
       {
           
           if(org !=''){
               if(org == data[i].org_name ){
               options += "<option  value='"+data[i].id+"'>"+ data[i].org_name +"</option>";
           }
           else{
               options += "<option value='"+data[i].id+"'>"+ data[i].org_name +"</option>";              
           }
           }
           else{
        options += "<option value='"+data[i].id+"'>"+ data[i].org_name +"</option>";
    }
       }

       select.append(options);
    }

});
}

$(document).ready(function(){
    populateRegions();
    populateOrgainzation(); 
    paralegalFilter();
    populateUnits();
    saveUser();
    edituserinfo();
    validateMobile();
    updatePassword();
    dateReport();
 viewReport();
$('#filter').on('click', function(e){
    $('.table').DataTable( {
    "bFilter": false,
    "bDestroy": true
  } );
       
       
       $('.pagination-detail').hide();
     //  $('.table').dataTable().clear()draw();
    e.preventDefault();
    var startDate = $('#startdate').val()

    var caseType = $("#casetype").val();
    if(startDate !=''){
     
    $('.table').DataTable().fnFilter($("#startdate").val()).draw(); // Manually redraw the table after filtering
           $('.table').DataTable( {
    "bFilter": false,
    "bDestroy": true
  } );
}
    if(caseType !=''){
    $('.table').DataTable().fnFilter($("#casetype").val()).draw(); // Manually redraw the table after filtering
           $('.table').DataTable( {
    "bFilter": false,
    "bDestroy": true
  } );
}


  });
 
// converts date strings to a Date object, then normalized into a YYYYMMMDD format (ex: 20131220). Makes comparing dates easier. ex: 20131220 > 20121220

 
    $("#startdate" ).datepicker({
            dateFormat: "dd-mm-yy",
            
            
	    
    });
    
    
});

$("#cancel").click(function(){
   $('input').val(""); 
   $('textarea').val("");  


 
});




function saveUser(){
    
    $("#username").keyup(function(){
         $("#exist_username").text("");
    $.post('userservice.php',{action:"check",username:$(this).val()},function(response){
       
        $("exist_username").show();
        if(response=="User name available"){
            $("#exist_username").css("color","green");
            
        }
        else{
            $("#exist_username").css("color","red");
            
        }
     $("#exist_username").text(response);
        
        
    });
    });
    $('.required').focus(function(){
    var id = $(this).attr("id");
   $("#error_"+id).hide();
   
});
$("#saveuser").click(function(){
    var error = false;
    $('.required').each(function(){
        var id = $(this).attr("id"); 
        
        
        
       if($(this).val()==""){
           error = true;
           $("#error_"+id).show();
           return ;
       } 
        
    });
    
    
    if(!error){
       $.post('userservice', {action:"save",name: $("#name").val(), username: $("#username").val(), password: $("#password").val(),type:$("#usertype").val()}, function (response) {
           $("#result").html('<div class="alert alert-success"><button type="button" class="close">×</button>'+response+'</div>');
           $(".alert").fadeTo(5000, 0).slideUp(500, function () {
         $(this).remove();
     });

           
           
                $(".required").val("");
            });
        
        
    }
});
    
}
function editUser(elem){
    var id = elem.closest('tr').children('.record').text();
    var url = "";
    var value = '';
  
  
  
  $('#outgoing').html('<form action="userservice.php" name="user" method="POST" style="display:none;"><input type="text" name="id" value="' + id + '" /><input type="text" name="action" value="edit" /></form>');

    document.forms['user'].submit();
    
}


function edituserinfo(){
     $("#username").keyup(function(){
         $("#exist_username").text("");
 
    });
    $('.required').focus(function(){
    var id = $(this).attr("id");
   $("#error_"+id).hide();
   
});
$("#edituser").click(function(){
    var error = false;
    $('.required').each(function(){
        var id = $(this).attr("id");
       if($(this).val()==""){
           error = true;
           $("#error_"+id).show();
           return ;
} 
    });
    
    
if(!error){
       $.post('userservice', {action:"editdata",name: $("#name").val(),id:$("#usr_id").val(),password: $("#password").val()}, function (response) {
           $("#result").html('<div class="alert alert-success"><button type="button" class="close">×</button>'+response+'</div>');
           $(".alert").fadeTo(5000, 0).slideUp(500, function () {
         $(this).remove();
     });

           
           
                $(".required").val("");
            });
        
        
    }
});
    
    
    
}


function deleteUser(elem){
    var id = elem.closest('tr').children('.record').text();
    var url = "";
    var value = '';
    
    $('#outgoing').html('<form action="userservice.php" name="user" method="POST" style="display:none;"><input type="text" name="id" value="' + id + '" /><input type="text" name="action" value="delete" /></form>');

    document.forms['user'].submit();
    
}



function validateMobile(){
    
    $("#mobile").keypress(function (e) {
    
     if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
    
        $("#errmsg").html("Digits Only").show().fadeOut("slow");
               return false;
    }
   });
   
   $("#mobile").focusout(function (){
       
       var mobile = $(this).val();
        var error = false;
       if(mobile.substring(0,3)!="255"){
           
          error = true;
       }
       if(mobile.length !=12){
           
           error = true;
       }
   if(error){
       $("#errmsg").html("Invalid Format").show().fadeOut("slow");
       $("#mobile").val("");
               return false;
   }    
   });
    
    
    
}


function saveUnits(){
            $("#saveUnit").click(function(){
                if($("#neworg").val()!= ''){
        $.post('paralegalservice.php', {action:"saveUnit",zones : $("#zones").val(),region: $("#region").val(),organization:'',org:$("#neworg").val(), unit: $("#unit").val()}, function (response) {
           $("#result").html('<div class="alert alert-success"><button type="button" class="close">×</button>'+response+'</div>');
           $(".alert").fadeTo(5000, 0).slideUp(500, function () {
         $(this).remove();
     });
        });
}
});
        
    
    
    $("#saveUnit").click(function(){
        $.post('paralegalservice.php', {action:"saveUnit",zones : $("#zones").val(),region: $("#region").val(), unit: $("#unit").val(),organization:$("#organization").val()}, function (response) {
           $("#result").html('<div class="alert alert-success"><button type="button" class="close">×</button>'+response+'</div>');
           $(".alert").fadeTo(5000, 0).slideUp(500, function () {
         $(this).remove();
     });
        
        
        });
    
    
    
    
});
}



function deleteParalegal(elem){
    var id = elem.closest('tr').children('.record').text();
    var url = "";
    var value = '';
    var phone = elem.closest('tr').children('.phone').text();
    $('#outgoing').html('<form action="paralegalservice.php" name="paralegal" method="POST" style="display:none;"><input type="text" value="'+phone+'" style="display:none" name="phone"><input type="text" name="id" value="' + id + '" /><input type="text" name="action" value="delete" /></form>');

    document.forms['paralegal'].submit();
    
}

function updatePassword(){
    
    $("#changepassword").click(function(){
        
        $.post('profileservice.php',{action:"changepassword",password:$("#password").val(),id:$("#id").val()},function(response){
        
        $("#result").html('<div class="alert alert-success"><button type="button" class="close">×</button>'+response+'</div>');
           $(".alert").fadeTo(5000, 0).slideUp(500, function () {
         $(this).remove();
    });
        });
});
}

function editParalegal(elem){
    
    var id = elem.closest('tr').children('.record').text();
    
    $('#outgoing').html('<form action="paralegalservice.php" name="paralegal" method="POST" style="display:none;"><input type="text" name="id" value="' + id + '" /><input type="text" name="action" value="edit" /></form>');
    document.forms['paralegal'].submit();
    
}



function updatePassword(){
    
    $("#changepassword").click(function(){
        
        $.post('profileservice.php',{action:"changepassword",password:$("#password").val(),id:$("#id").val()},function(response){
        
        $("#result").html('<div class="alert alert-success"><button type="button" class="close">×</button>'+response+'</div>');
           $(".alert").fadeTo(5000, 0).slideUp(500, function () {
         $(this).remove();
    });
        });
});
}

function viewCaseStatus(elem){
    var status = elem.text();
    
    if(status == "End Without Solution"){
        
        status = "Endwithoutsolution";
    }
   
    
    $.post('loadpage.php',{div:"reports-"+status},function(response){
         location.href = 'reports-Detail';
        });
}
function caseType(elem){
    var caseType = elem.text();
    if(caseType=="Sexual Harrasment"){
	caseType = "Sexual-Harrasment";
}
    if(caseType == "Child Maintenance"){
        caseType = "Child-Maintanence";
    }

if(caseType=="Child Custody"){

        caseType = 'Child-Custody';
    }


if(caseType=="Child Cus"){        
        caseType = 'Child-Custody';
    }
 
    $.post('loadpage.php',{div:"reports-"+caseType,caseTypes:caseType},function(response){
         location.href = 'reports-Detail';
        });
}
function sourceBase(elem){
     var source = elem.text(); 
     
     $.post('loadpage.php',{div:"reports-"+source},function(response){
         location.href = 'reports-Detail';
        });
}
function viewgenderbase(elem){
    var gender = elem.text();
    $.post('loadpage.php',{div:"reports-"+gender},function(response){
         location.href = 'reports-Detail';
        });
}

$("#updateparalegal").click(function(){
    
   var error = false;
    $('.required').each(function(){
        var id = $(this).attr("id"); 
        if($(this).val()==""){
           error = true;
           $("#error_"+id).show();
           return ;
       } 
        
    });
    
	    

    if(!error){ 
       $.post('paralegalservice.php', {action:"editparalegal",paralegal_id : $("#paralegalid").val(),name: $("#name").val(), age: $("#age").val(), address: $("#address").val(), region: $("#region").val(), district: $("#district").val(), village_area: $("#village").val(), phone_number: $("#mobile").val(),unit:$("#units").val(),username:$("#uname").val(),password:$("#password").val(),fname:$("#name").val(),type:$("#type").val(),login_id:$("#loginid").val(),status:$("#status").val()}, function (response) {
           $("#result").html('<div class="alert alert-success"><button type="button" class="close">×</button>'+response+'</div>');
           $(".alert").fadeTo(50000, 0).slideUp(500, function () {
         $(this).remove();
     });
           
           $(".required").val("");
            });
        
        
    } 
    
});

function viewParalegalperformance(elem){
   var org = elem.text();
    location.href = 'reports-Paralegal-Perfromence?Organization='+org;
    
    
    
}

function gbvType(elem){
    
    var gbvType = elem.text();
    
    gbvType = gbvType.replace(/\s/g, "-");
    location.href = 'reports-'+gbvType;
    
    
}

function dateReport(){
    $("#dt").click(function(){
        $(".pagination-detail").hide();
    $(".pull-right").hide();
       var table = $('.table').DataTable({bFilter: true, bInfo: false,
    "bDestroy": true});
     table.fnFilter($("#startdate").val()).fndraw(); // Manually redraw the table after filtering
    
    });
    
    
}

 function menuLabel(){
        
        $(".fa-caret-down").click(function(){
            $(this).removeClass("fa-caret-left");
            $(this).addClass("fa-caret-up");
        });
        
       
    }
function viewReport(){
    var selectedval = '';
    $('.filter').click(function(){
         var id = $(this).attr("id");
         selectedval =  $("#"+id).val();
         console.log(selectedval);
    });
    
   
    
    
$('.filter').change( function() {   
$("#DataTables_Table_0_filter").hide();
   var val = $("#filter").val();
   
   if(val !=''){
       val = $("#filter").val();
       val = val.replace(selectedval,'');
       $("#filter").val(val+" "+$(this).val());
       
   }
   else{
   $("#filter").val($(this).val());    
   }
   val = $("#filter").val();
   if(val=="any"){
       val = '';
   }
   //val = val.replace(selectedval,'');
    $(".pagination-detail").hide();
    $(".pull-right").hide();
            $('.table').DataTable({bFilter: true, bInfo: false,
    "bDestroy": true}).fnFilter(val).fndraw(); 
    $("#DataTables_Table_0_filter").hide();
       });
     
       
}




function paralegalFilter(){
$("#paralegalfilter").click(function(){
     
    $(".pagination-detail").hide();
    $(".pull-right").hide();
    var mobile = $("#mobile").val();
    var name = $("#name").val();
    var table = $('.table').DataTable({bFilter: true, bInfo: false,
    "bDestroy": true});
    if(name !=''){
     table.fnFilter($("#name").val()).fndraw(); // Manually redraw the table after filtering
    
    }
 if(mobile!=''){
     
 table.fnFilter(($("#mobile").val())).fndraw(); // Manually redraw the table after filtering   
        
 }
 
 
});
}


function scrwidth(){
    
    $(window).resize(function(){
         var width = $(window).width();
        if(width < 771){    
           $("#menu").hide();
           $("#collapsemenu").show();
        }
        else{
            $("#collapsemenu").hide();
            $("#menu").show(); 
        }
    });
    var width = $(window).width();
        if(width < 771){    
           $("#menu").hide();
           $("#collapsemenu").show();
        }
        else{
            $("#collapsemenu").hide();
            $("#menu").show(); 
        }
    }
    

    
    
function populateUnits(){
    
     
         var id = $("#organization").val();
         
     
         $.ajax({
    type: "POST",
    url: 'paralegalservice.php',
    data: {action:"getUnits",org:id},
    dataType:'json',
    success: function(data) {
       var select = $("#units"), options = '';
       select.empty();      
       for(var i=0;i<data.length; i++)
       {
           if(unit!=''){
           if(unit == data[i].unit_name){
               
               options += "<option selected = 'selected'  value='"+data[i].id+"'>"+ data[i].unit_name +"</option>";              
           }
           else{
        options += "<option value='"+data[i].id+"'>"+ data[i].unit_name +"</option>";              
    }
           }
           else{
               
               options += "<option value='"+data[i].id+"'>"+ data[i].unit_name +"</option>";              
           }
       }
       select.append(options);
    }
    
    
    
    
});
     
    $("#organization").change(function() {
        
         var id = $("#organization").val() ;
         
    $.ajax({
    type: "POST",
    url: 'paralegalservice.php',
    data: {action:"getUnits",org:id},
    dataType:'json',
    success: function(data) {

       var select = $("#units"), options = '';
       select.empty();      

       for(var i=0;i<data.length; i++)
       {
        options += "<option value='"+data[i].id+"'>"+ data[i].unit_name +"</option>";              
       }

       select.append(options);
    }
    
    
    
    
});
        
    });
   

}

