<?php
ob_start();
session_start();

include_once './includes/session.php';

include_once './includes/header.php';
echo "<script type='text/javascript'> var region  = '' </script>";
echo "<script type='text/javascript'> var unit  = '' </script>";
echo "<script type='text/javascript'> var org  = '' </script>";
//$action = 'add';
include_once 'paralegalservice.php';
$title = "LSF | Add Paralegal";
$pageContents = ob_get_contents();
$activePage = 'paralegal';
ob_end_clean();
echo str_replace('<!--TITLE-->', $title, $pageContents);

$regions = array("Arusha", "Dar es Salaam", "Dodoma", "Geita", "Iringa", "Kagera", "Katavi", "Kigoma", "Kilimanjaro",
    "Lindi", "Manyara", "Mara", "Mbeya", "Morogoro", "Mtwara", "Mwanza", "Njombe", "Pemba Kaskazini", "Pemba Kusini", "Pwani",
    "Rukwa", "Ruvuma", "Shinyanga", "Simiyu", "Singida", "Tabora", "Tanga", "Unguja Kaskazini", "Unguja Magharibi", "Zanzibar Kati/Kusini");
?>
<?php include 'includes/bottom_header_part.php'; ?>
<!--<div class="navbar-tools">
<?php
//include_once './includes/top.php';
?>
                    </div>
                    </div>    
                </div>-->
<!--                   <div class="main-container">
                <div class="navbar-content">
                    <div class="main-navigation navbar-collapse collapse">
<?php //include('includes/menu.php'); ?>
                    </div>
                   
                </div>
             </div>-->
<div class="row">
    <div class="col-xs-12 col-sm-6 col-md-3" id="side_menu">
        <?php
        include('includes/side_menu.php');
        ?>
        </div>
    <div class="col-xs-12 col-sm-6 col-md-3"></div>
    <div class="col-xs-12 col-sm-6 col-md-9" id="center_body">
            <div class="panel-body">

                        <h2><?php echo "Add Paralegal"; ?></h2>
                        <hr>

                        <div id="result">


                        </div>


                        <div class="form-group">
                            <label class="col-sm-4 control-label" for="group-name">
                                Name
                            </label>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <input type="text" name="name" id="name" class="form-control required">
                                    <label id="error_name" style="color: red;display:none">Name is Missing</label>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-sm-4 control-label" id = "addresses" for="group-name">
                                Address
                            </label>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <textarea  name="address" id="address" class="form-control required">
                                    </textarea>   
                                    <label id="error_address" style="color: red;display:none">Address is Missing</label>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-sm-4 control-label" for="group-name">
                                Zones
                            </label>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <select id="zones" name="zones" class="form-control">
                                        <?php foreach ($zones as $value) { ?>
                                            <option value="<?php echo $value['id']; ?>"><?php echo $value['zone_name']; ?></option>
                                        <?php } ?>
                                    </select>
                                    <label id="error_region" style="color: red;display:none">Region is Missing</label>
                                </div>
                            </div>
                        </div>


                        <div class="form-group">
                            <label class="col-sm-4 control-label" for="group-name">
                                Region
                            </label>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <select id="region" name="region" class="form-control">

                                    </select>
                                    <label id="error_region" style="color: red;display:none">Region is Missing</label>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-sm-4 control-label" for="group-name">
                                District
                            </label>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <input type="text" name="district" id="district" class="form-control required" value="">
                                    <label id="error_district" style="color: red;display:none">District is Missing</label>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-4 control-label" for="group-name">
                                Ward
                            </label>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <input type="text" name="village" id="village" class="form-control required" value=""> 
                                    <label id="error_village" style="color: red;display:none">Village is Missing</label>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-4 control-label" for="group-name">
                                Mobile
                            </label>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <input type="text" name="mobile" id="mobile" class="form-control required" value="">
                                    <label id="error_mobile" style="color: red;display:none">Mobile is Missing</label>
                                    <label id="errmsg" style="color: red;display:block"></label>
                                </div>
                            </div>
                        </div>


                        <div class="form-group">
                            <label class="col-sm-4 control-label" for="group-name">
                                Organization
                            </label>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <select id="organization" class="form-control">

                                    </select>
                                    <label id="error_organization" style="color: red;display:none">Mobile is Missing</label>
                                </div>
                            </div>
                        </div>



                        <div class="form-group">
                            <label class="col-sm-4 control-label" for="group-name">
                                Units
                            </label>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <select id="units" class="form-control">

                                    </select>
                                    <label id="error_units" style="color: red;display:none">Mobile is Missing</label>
                                </div>
                            </div>
                        </div>


                        <!--div class="form-group">
                                       <label class="col-sm-4 control-label" for="group-name">
                                           Name
                                       </label>
                                       <div class="col-sm-6">
                                       <div class="form-group">
                                       <input type="text" name="fname" id="fname" class="form-control required" value="">
                                       <label id="error_fname" style="color: red;display:none">Name is missing</label>
                                       <label id="errmsg" style="color: red;display:block"></label>
                                       </div>
                               </div>
                               </div!-->


                        <div class="form-group">
                            <label class="col-sm-4 control-label" for="group-name">
                                Username
                            </label>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <input type="text" name="uname" id="uname" class="form-control " value="">
                                    <label id="error_uname" style="color: red;display:none">User name is missing</label>
                                    <label id="errmsg" style="color: red;display:block"></label>
                                </div>
                            </div>
                        </div>



                        <div class="form-group">
                            <label class="col-sm-4 control-label" for="group-name">
                                Password
                            </label>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <input type="password" name="password" id="password" class="form-control" value="">
                                    <label id="error_password" style="color: red;display:none">Password is missing</label>
                                    <label id="errmsg" style="color: red;display:block"></label>
                                </div>
                            </div>
                        </div>


                        <div class="form-group">
                            <label class="col-sm-4 control-label" for="group-name">
                                Type
                            </label>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <select id="type" name="type" id="type" class="form-control">
                                        <option value="Paralegal Admin">Paralegal Admin</option>
                                        <option value="Paralegal User">Paralegal User</option>
                                    </select>
                                </div>
                            </div>
                        </div>


                        <div class="form-group">
                            <label class="col-sm-4 control-label" for="crete">
                            </label>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <a href="#">
                                        <button id="cancel" type="button" class="btn btn-danger">
                                            Cancel <i class="icon-circle-arrow-cross"></i>
                                        </button></a>
                                    <button type="submit" name="saveparalegal" id="saveparalegal" class="btn btn-primary">
                                        Save <i class="icon-circle-arrow-right"></i>
                                    </button></div>
                            </div>
                        </div>


                    </div> 
        
    </div>
</div>




<?php
include_once './includes/footer.php'
?>
