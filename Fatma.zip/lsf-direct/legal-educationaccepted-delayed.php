<?php
ob_start();
session_start();

include_once './includes/session.php';

include_once './includes/header.php';
$title = "LSF | LegalEducation";
$pageContents = ob_get_contents();
$activePage = 'legaleducationaccepted';
ob_end_clean();
echo str_replace('<!--TITLE-->', $title, $pageContents);
?>
<style type="text/css" >td:last-child{
        width:100%
    }</style>
<!--<div class="navbar-tools">
<?php
//include_once './includes/top.php';
?>
                    </div>
                    </div>    
                </div>-->

<?php include 'includes/bottom_header_part.php'; ?>
<div class="row">
    <div class="col-xs-12 col-sm-6 col-md-3" id="side_menu">
        <?php
        include('includes/side_menu.php');
        ?>
    </div>
     <div class="col-xs-12 col-sm-6 col-md-3"></div>
    <div class="col-xs-12 col-sm-6 col-md-9" id="center_body">
        <div class="panel panel-default" id="style_top_pannels">
            <form action="download.php" method="POST"  class="form-inline" >
                                            <input type="hidden" name="report" value="Legal-Education-Delayed"/>
                                            <input type="submit" class="btn btn-warning btn-xs" name="export" value="Export AS Excel"/>
                                            <input type="submit" class="btn btn-danger btn-xs" name="exportpdf" value="Export AS PDF"/>
                                           </form>
            <div class="panel-body">
                <div class="col-xs-12 col-sm-6 col-md-12">
                    <form class="form-inline">
                        <div class="col-xs-12 col-sm-6 col-md-12">
                            <div class="form-group">
                                <!--                                <label for="exampleInputName2">STD</label>-->
                                <input type="text" name="std" class="form-control input-sm" id="exampleInputName2" placeholder="Start Date">
                            </div>
                            <div class="form-group">
                                <!--                                <label for="exampleInputEmail2">EDT</label>-->
                                <input type="text" name="edt" class="form-control input-sm" id="exampleInputEmail2" placeholder="End Date">
                            </div>
                            <div class="form-group">                       
                                <!--<input type="text" name="unit" class="form-control" id="exampleInputEmail2" placeholder="Unit">-->
                                <select name="unit" class="form-control input-sm">
                                    <option>All Units</option>
                                    <option>Unit 1</option>
                                    <option>Unit 2</option>
                                    <option>Unit 3</option>
                                </select>
                            </div>

                            </td>
                        </div><div class="col-xs-12 col-sm-6 col-md-12"><br>
                            <div class="collapse" id="collapseExample">
                                <div class="form-group">                       
                                    <input type="text" name="eventType" class="form-control input-sm" id="exampleInputEmail2" placeholder="Event Type">
                                </div>
                                <div class="form-group">                

                                    <select name="gender" class="form-control input-sm">
                                        <option>All Gender</option>
                                        <option>Male</option>
                                        <option>Female</option>                            
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail2">Unit333</label>
                                    <input type="text" name="unit2" class="form-control input-sm" id="exampleInputEmail2" placeholder="jane.doe@example.com">
                                </div>
                                <div class="form-group">
                                    <input class="btn btn-warning" type="submit" value="Search">
                                </div>
                            </div></div>
                    </form>
                </div>
            </div>
            <button class="btn btn-bricky btn-xs dropdown-toggle" type="button" data-toggle="collapse" href="#collapseExample" aria-expanded="false" aria-controls="collapseExample">
                More Filter Options
                <span class="caret"></span>
            </button>
            <!-- <button class="btn btn-default btn-xs dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" >
                MORE FILTER OPTIONS <span class="caret"></span>
              </button>-->
        </div>

        <!--             <div class="main-container">
                        <div class="navbar-content">
                             start: SIDEBAR 
                            <div class="main-navigation navbar-collapse collapse">
                                 start: MAIN MENU TOGGLER BUTTON 
                                <div class="navigation-toggler">
                                    <i class="clip-chevron-left"></i>
                                    <i class="clip-chevron-right"></i>
                                </div>
                                
        <?php //include('includes/menu.php'); ?>
                            </div>
                           
                        </div>
                     
                        
                        <div class="main-content">
                            <div class="container">
                                 start: PAGE HEADER 
                                <div class="row">
                                    
                                       <div id="outgoing"> 
                                       </div>
                                    
                                    
                                    <div id="incoming"> 
                                       </div>
                                 </div>
                                
                                
                                
                                
                            <div class="row">
                                <div class="col-sm-12">
                                     start: DATE/TIME PICKER PANEL 
                                    <div class="panel">
                                        <div class="panel-body">
        
                                            <div style="display: inline;width: 100px; font-size:30px;">Legal Education</div>
                                            
                                            
                                            
                                        </div>
                                         end: DATE/TIME PICKER PANEL 
                                    </div>
                                </div>
                            </div>
        <div class="row nonajax">-->
        <table  class="table table-condensed" data-toggle="table" data-url="legaleducationservice.php/?action=accepteddelayed"  data-show-refresh="true" data-show-toggle="false" data-show-columns="false" data-search="true" data-select-item-name="toolbar1" data-pagination="true" data-sort-name="name" data-sort-order="desc" >
            <thead id="style_top_table" style="font-size: 12px">
                <tr>
                    <th data-field="record_id" class="record"></th>
                    <th data-field="Submitted" data-sortable="true">Submission Date </th>
                    <th data-field="phone_number" data-sortable="true">Mobile</th>
                    <th data-field="name" data-sortable="true">Submitted By</th>
<!--                    <th data-field="unit_name" data-sortable="true">Unit</th>-->
                    <th data-field="Event Date" data-sortable="true">Event Date</th>
                    <th data-field="event_type" data-sortable="true">Event Type</th>
                    <th data-field="topic_discussed" data-sortable="true" class="topic">Topic</th>
                    <th data-field="village_location" data-sortable="true">Village</th>
                    <th data-field="Male" data-sortable="true">Males</th>
                    <th data-field="Female" data-sortable="true">Females</th>
                    <th data-field="duration" data-sortable="true">Duration</th>

                </tr>
            </thead>
        </table>
    </div>





</div>

<?php
include_once './includes/footer.php';
?>