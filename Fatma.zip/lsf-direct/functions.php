<?php
include_once 'query.php';

$query = new query();

$sql = "SELECT distinct topic_discussed from legal_education_direct";
$result = $query::select($sql);
$topics = array();
while($row = mysql_fetch_array($result)){
    
    
    $topics[] = $row;
}

$sql = "SELECT org_name from org_details";
$result = $query::select($sql);
$org = array();
while($row = mysql_fetch_array($result)){
    
    
    $org[] = $row;
}

$sql = "SELECT unit_name from paralegal_units";
$result = $query::select($sql);
$unit = array();
while($row = mysql_fetch_array($result)){
    
    
    $unit[] = $row;
}