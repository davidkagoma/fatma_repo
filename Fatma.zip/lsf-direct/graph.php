<script type="text/javascript">
$(function () {
    
// total disputes
    
$("#totdisputes").highcharts({
    tooltip: { enabled: false },
chart:{
plotBackgroundColor: null,
            plotBorderWidth: null,
            plotShadow: false,
type: 'pie'
},
title:{
text : ''
},
plotOptions: {
            pie: {
                 allowPointSelect: true,
            }
        },
        series: [{
                 showInLegend: false, 
            
            data: [
                ['Ongoing : <?php echo $dispute[0]['Ongoing']?>',<?php echo $dispute[0]['Ongoing']?> ],
                ['Resolved: <?php echo $dispute[0]['Resolved']?>', <?php echo $dispute[0]['Resolved']?> ],
                ['End Without Solution : <?php echo $dispute[0]['END']?>', <?php echo $dispute[0]['END']?>],
                ['Reffered : <?php echo $dispute[0]['Reffered']?>', <?php echo $dispute[0]['Reffered']?>],
                
            ]
        }]
});    
    
});





$('#totcase').highcharts({
tooltip: { enabled: false },
        chart: {
            type: 'column'
        },
        title: {
            text: ''
        },
        subtitle: {
            text: ''
        },
        
        yAxis: {
            title: {
                text: 'Number of Disputes'
            }
        },
        plotOptions: {
            line: {
                dataLabels: {
                    enabled: true
                },
                enableMouseTracking: false
            }
        },
        
                
                        series: [{             
                        name : 'Child Maintanence',                                                   
                        data :[<?php echo $casetype[0]['Child']?>
                        ]
        },
                 {
            name: 'Labour',
            data: [<?php echo $casetype[0]['Labour']?>
            ]
        },
                 
                 {
            name: 'Matrimonial',
            data: [<?php echo $casetype[0]['Matrimonial']?>]
        },
        
        
         {
            name: 'Land',
            data: [<?php echo $casetype[0]['Land']?>
            ]
        },
        
        {
            name: 'Civil',
            data: [<?php echo $casetype[0]['Civil']?>
            ]
        },
        
        
       
        
        ]
    });
    
    
    
$('#gendertypepercent').highcharts({
tooltip: { enabled: false },
        chart: {
            type: 'column'
        },
        title: {
            text: ''
        },
        subtitle: {
            text: ''
        },
      
        yAxis: {
            title: {
                text: 'Number of Cases received'
            }
        },
        xAxis : {
        categories: [
               'Child Maintainance',
               'Child Custody',
               'Civil',
               'Labour',
               'Land',
               'Matrimonial',
               'GBV',
               'Other',
               'Rape',
               'Sexual Harrasment',
               'Wife Beating',
               'Criminal'
            ],
    
            title : {
                title : 'Cases'
            }
        
        },
        plotOptions: {
            line: {
                dataLabels: {
                    enabled: true
                },
                enableMouseTracking: false
            }
        },
        
                
               series :[{
         name:'Male',
         data:[<?php foreach($casegenderbase as $key=>$index){ echo  $casegenderbase[$key]['Male']; ?>,<?php } ?>
         ]  
            
        },
                {
         name:'Female',
         data:[<?php foreach($casegenderbase as $key=>$index){ echo  $casegenderbase[$key]['Female']; ?>,<?php } ?>
         ]
                }]
    });
    
    $('#gender').highcharts({
    chart: {
            type: 'column'
        },
        title: {
            text: ''
        },
        subtitle: {
            text: ''
        },
        xAxis: {
        title : {
        text : 'Sex'
        },
            categories: [
               'Male','Female'
               
            ],
            crosshair: true
        },
        yAxis: {
            min: 0,
            title: {
                text: 'Number of Cases Resolved'
            }
        },
       
        plotOptions: {
            column: {
            stacking: 'normal',
                pointPadding: 0.2,
                borderWidth: 0
            }
        },
        series :[{
        colorByPoint: true,
         name:'Gender',
         data:[<?php echo $genderbase[0]['Male']?>,<?php echo $genderbase[0]['Female']?>] 
            
        },
                ]
    });
    
    
    
    
    
    /*$('#gender').highcharts({
    tooltip: { enabled: false },
        chart: {
            type: 'column'
        },
        title: {
            text: ''
        },
        subtitle: {
            text: ''
        },


     xAxis: {
        title : {
        text : ''
        },
            categories: ['Male','Female'],
            crosshair: true
        },       

 
        yAxis: {
            title: {
                text: 'Number of Cases Received by Sex'
            }
        },
        plotOptions: {
            line: {
                dataLabels: {
                    enabled: true
                },
                enableMouseTracking: false
            }
        },
        
                xAxis:{
                title:{
                    text: 'Sex'
                }
                },

  plotOptions: {
            line: {
                dataLabels: {
                    enabled: true
                },
                enableMouseTracking: false
            }
        },


                        series: [{             
                        name : 'Male',                                                   
                        data :[<?php echo $genderbase[0]['Male']?>
                        ]
        },
                 {
            name: 'Female',
            data: [<?php echo $genderbase[0]['Female']?>
            ]
        },
                 
                 
        
       
        
        ]
    });*/
    
    
    
 $('#casetype').highcharts({
    chart: {
            type: 'column'
        },
        title: {
            text: ''
        },
        subtitle: {
            text: ''
        },
        xAxis: {
        title : {
        text : 'Cases'
        },
            categories: [
               'Child Maintainance',
               'Child Custody',
               'Civil',
               'Labour',
               'Land',
               'Matrimonial',
               'GBV',
               'Other',
               'Rape',
               'Sexual Harrasment',
               'Wife Beating'
            ],
            crosshair: true
        },
        yAxis: {
            min: 0,
            title: {
                text: 'Number of Cases Resolved'
            }
        },
       
        plotOptions: {
            column: {
                pointPadding: 0.2,
                borderWidth: 0
            }
        },
        series :[{
         name:'Male',
         data:[<?php echo $childgenderbase[0]['Male'];?>,<?php echo $childcustodygenderbaseresolved[0]['Male'];?>,<?php echo $civilgenderbase[0]['Male'];?>,<?php echo $labourgenderbase[0]['Male']?>,<?php echo $landgenderbase[0]['Male']?>,<?php echo $matrimonialgenderbase[0]['Male']?>,<?php echo $gbvgenderbase[0]['Male']?>,<?php echo $othergenderbase[0]['Male']?>,<?php echo $rapegenderbase[0]['Male']?>,<?php echo $sexgenderbase[0]['Male']?>,<?php echo $wifebeatinggenderbase[0]['Male']?>] 
            
        },
                {
         name:'Female',
         data : [<?php echo $childgenderbase[0]['Female'] ?>,<?php echo $childcustodygenderbaseresolved[0]['Female'];?>,<?php echo $civilgenderbase[0]['Female']?>,<?php echo $labourgenderbase[0]['Female']?>,<?php echo $landgenderbase[0]['Female']?>,<?php echo $matrimonialgenderbase[0]['Female']?>,<?php echo $gbvgenderbase[0]['Female']?>,<?php echo $othergenderbase[0]['Female']?>,<?php echo $rapegenderbase[0]['Female']?>,<?php echo $sexgenderbase[0]['Female']?>,<?php echo $wifebeatinggenderbase[0]['Female']?>]
                }]
    });
    
    

 $("#casetypepercent").highcharts({
 tooltip: { enabled: false },
chart:{
plotBackgroundColor: null,
            plotBorderWidth: null,
            plotShadow: false,
type: 'pie'
},
title:{
text : ''
},
plotOptions: {
            pie: {
                 allowPointSelect: true,
            }
        },
        series: [{
             showInLegend: false, 
            name: '',
            data:[ ['Ongoing :<?php echo $ongoingperc?>',<?php echo $ongoingperc?>
            ],
            ['Resolved :<?php echo $resolvedperc; ?>', <?php echo $resolvedperc; ?>
            ],
            ['Referred : <?php echo $refferedperc; ?>', <?php echo $refferedperc; ?>
            ],
            ['End without solution <?php echo $endperc; ?>', <?php echo $endperc; ?>
            ]
           ] }]
        
}); 
 
 
 
 $("#educationgenderbase").highcharts({
 tooltip: { enabled: false },
chart:{
plotBackgroundColor: null,
            plotBorderWidth: null,
            plotShadow: false,
type: 'pie'
},
title:{
text : ''
},
plotOptions: {
            pie: {
                 allowPointSelect: true,
            }
        },
        series: [{
         showInLegend: false, 
            name: '',
            data:[ ['Male :<?php echo number_format($edumaleperc); ?>',<?php echo number_format($edumaleperc); ?>
            ],
            ['Female :<?php echo number_format($edufemaleperc); ?>', <?php echo number_format($edufemaleperc); ?>
            ],
            
           ] }]
        
}); 
 

 $("#casestatusperc").highcharts({
chart:{
plotBackgroundColor: null,
            plotBorderWidth: null,
            plotShadow: false,
type: 'pie'
},
title:{
text : 'Status of the case reported'
},
plotOptions: {
            pie: {
                 allowPointSelect: true,
            }
        },
        series: [{
            name: 'Status of the case',
            data:[ ['Ongoing',<?php echo $totongoingperc; ?>
            ],
            ['Resolved', <?php echo $totresolvedperc; ?>
            ],
            ['Referred', <?php echo $totrefferedperc; ?>
            ],
            ['End without solution', <?php echo $totendperc; ?>
            ],
            
           ] }]
        
}); 
 


$("#sourcebase").highcharts({
tooltip: { enabled: false },
chart:{
plotBackgroundColor: null,
            plotBorderWidth: null,
            plotShadow: false,
type: 'pie'
},
title:{
text : ''
},
plotOptions: {
            pie: {
                 allowPointSelect: true,
            }
        },
        series: [{
         showInLegend: false, 
            name: '',
            data:[ ['Android : <?php echo $androidperc; ?>',<?php echo $androidperc; ?>
            ],
            ['USSD : <?php echo $ussdperc; ?>', <?php echo $ussdperc; ?>
            ]
            
            
           ] }]
        
}); 

/*$("#gbvreferred").highcharts({
tooltip: { enabled: false },
chart:{
plotBackgroundColor: null,
            plotBorderWidth: null,
            plotShadow: false,
type: 'pie'
},
title:{
text : ''
},
plotOptions: {
            pie: {
                 allowPointSelect: true,
            }
        },
        series: [{
            name: 'Status of the case',
            data:[ ['Ongoing',<?php echo $totongoingperc; ?>
            ],
            ['Resolved', <?php echo $totresolvedperc; ?>
            ],
            ['Referred', <?php echo $totrefferedperc; ?>
            ],
            ['End without solution', <?php echo $totendperc; ?>
            ],
            
           ] }]

});*/
</script>
