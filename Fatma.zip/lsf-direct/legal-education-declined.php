<?php
ob_start();
session_start();

include_once './includes/session.php';

include_once './includes/header.php';
$title = "LSF | LegalEducation";
$pageContents = ob_get_contents ();
$activePage = 'legaleducationdeclined';
ob_end_clean (); 
echo str_replace ('<!--TITLE-->', $title, $pageContents);
?>

<?php include 'includes/bottom_header_part.php'; ?>
<div class="row">
    <div class="col-xs-12 col-sm-6 col-md-3" id="side_menu">
        <?php
        include('includes/side_menu.php');
        ?>
    </div>
     <div class="col-xs-12 col-sm-6 col-md-3"></div>
    <div class="col-xs-12 col-sm-6 col-md-9" id="center_body">
        <div class="panel panel-default" id="style_top_pannels">
            <form action="download.php" method="POST"  class="form-inline" >
                                            <input type="hidden" name="report" value="Legal-Education-Declined"/>
                                            <input type="submit" class="btn btn-warning btn-xs" name="export" value="Export AS Excel"/>
                                            <input type="submit" class="btn btn-danger btn-xs" name="exportpdf" value="Export AS PDF"/>
                                           </form>
            <div class="panel-body">
                <div class="col-xs-12 col-sm-6 col-md-12">
                    <form class="form-inline">
                        <div class="col-xs-12 col-sm-6 col-md-12">
                            <div class="form-group">
                                <input type="text" name="std" class="form-control input-sm" id="startdate" placeholder="Submission Date">
                                 <input class="btn btn-warning" id ="dt" type="button" value="Search">
                            </div>
                            <div class="form-group">
                            </div>
                            <div class="form-group">                       
                            </div>

                            </td>
                        </div><div class="col-xs-12 col-sm-6 col-md-12"><br>
                            <div class="collapse" id="collapseExample">
                                <div class="form-group">                       
                                    <select class="form-control input-sm filter">
                                        <option value="any">Select Event </option>
                                        <option value="Village">Village</option>
                                        <option value="Women">Women</option>
                                        <option value="Festival">Festival</option>
                                        <option value="Ceremony">Ceremony</option>
                                        <option value="Vikoba">Vikoba</option>
                                        <option value="Farmers">Farmers</option>
                                        <option value="Pastoralist">Pastoralist</option>
                                        <option value="Video">Video</option>
                                        <option value="Radio">Radio</option>
                                        <option value="School">School</option>
                                        <option value="Others">Others</option>
                                    </select>
                                </div>
                                <div class="form-group">                

                                    <select name="gender" class="form-control input-sm filter">
                                        <option>All Gender</option>
                                        <option>Male</option>
                                        <option>Female</option>                            
                                    </select>
                                </div>                               
                                <div class="form-group">
                                    <input class="btn btn-warning" type="submit" value="Search">
                                </div>
                            </div></div>
                    </form>
                </div>
            </div>
              <button class="btn btn-bricky btn-xs dropdown-toggle" type="button" data-toggle="collapse" href="#collapseExample" aria-expanded="false" aria-controls="collapseExample">
            More Filter Options
            <span class="caret"></span>
        </button>
        </div>

   <table  class="table table-condensed" data-toggle="table" data-url="legaleducationservice.php/?action=declined"  data-show-refresh="true" data-show-toggle="false" data-show-columns="false" data-search="true" data-select-item-name="toolbar1" data-pagination="true" data-sort-name="name" data-sort-order="desc" >
       <input type="text" id="filter" style="display:none"/>
                    <thead id="style_top_table" style="font-size: 12px">
                    <tr>
                        <th data-field="record_id" class="record"></th>
                        <th data-field="Submitted" data-sortable="true">Submission Date </th>
                        <th data-field="phone_number" data-sortable="true">Mobile</th>
                        <th data-field="name" data-sortable="true">Submitted By</th>
                        <th data-field="EventDate" data-sortable="true">Event Date</th>
                        <th data-field="event_type" data-sortable="true">Event Type</th>
                        <th data-field="topic_discussed" data-sortable="true" class="topic">Topic</th>
                        <th data-field="village_location" data-sortable="true">Village</th>
                        <th data-field="Male" data-sortable="true">Males</th>
                        <th data-field="Female" data-sortable="true">Females</th>
                        <th data-field="duration" data-sortable="true">Duration</th>
                    </tr>
                    </thead>
                </table>
</div>
                        
                        
                        
                        
                        
                </div>
          
<?php
include_once './includes/footer.php';
?>
