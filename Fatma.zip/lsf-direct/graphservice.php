<?php

include_once 'query.php';
//error_reporting(0);
$query = new query();
session_start();

   if($_SESSION['type']=='super admin'){
    
    $where = "1=1";
    
}

else{
    
    $sql = "SELECT unit_id from paralegals where login_id = {$_SESSION['loginid']}";
    $result = $query :: select($sql);
    $row = mysql_fetch_array($result);
    $unitid = $row['unit_id'];
    
    $where = "unit_id = {$unitid}";
}


// disputes monthly wise 
$legaleducation = "SELECT count(Male) as 'Males',count(Female) as 'Females' from LegalEducationDirectView where $where";
$result = $query :: select($legaleducation);
$educationarray = array();
while($row=  mysql_fetch_array($result)){
    
    $educationarray[] = $row;
}


$legalaid = "SELECT count(case when gender = 'Male' THEN 1 END) AS 'Male',count(case when gender  = 'Female' THEN 1 END) AS 'Female' from LegalAidDirectView where $where";
$result = $query :: select($legalaid);
$aidarray = array();
while($row=  mysql_fetch_array($result)){
    $aidarray[] = $row;
}


$aid = "select count(record_id) as 'cases',monthname(Submitted) from LegalAidDirectView WHERE $where group by  monthname(Submitted),year(Submitted) ";

$result = $query :: select($aid);
$aidgraph = array();
while($row =  mysql_fetch_array($result)){
    
    $aidgraph[] = $row;
}
$sql="SELECT count(record_id) as `totaldisputes`,monthname(Submitted) as `month`,month(Submitted) FROM LegalAidDirectView WHERE    year(Submitted) = 2015 and  month(Submitted) <= month(curdate()) AND $where group by monthname(Submitted),month(Submitted) order by month(Submitted) asc";
			$total=$query :: select ($sql);
                        
                        $totl = array();
                        while($totrow = mysql_fetch_array($total)){    
                            $totl[] = $totrow;
                        }
			
                        
                        //ongoing   
                        $sql  = "SELECT count(record_id) as `id`,monthname(Submitted) FROM LegalAidDirectView WHERE   case_status  = 'Ongoing'  AND $where and year(Submitted) = 2015 and month(Submitted) <= month(curdate()) group by monthname(Submitted) order by month(Submitted) asc";

			$ongoing = $query :: select ($sql);
                        
                        
                        $ongng = array();
                        while($row = mysql_fetch_array($ongoing)){
                            $ongng[] = $row; 
                            
                        }
                        
                        //Referred disputes 
			$sql="SELECT count(record_id) as `referred`,monthname(Submitted) FROM LegalAidDirectView  WHERE   case_status='Reffered' AND $where  and year(Submitted) = 2015 and month(Submitted) <= month(curdate()) group by monthname(Submitted) order by month(Submitted) asc";
			$referred= $query :: select ($sql);
			$ref  = array();
                        while($refrow = mysql_fetch_array($referred)){
                            $ref[] = $refrow;
                        }
                        
                        //solved
			$sql="SELECT count(record_id) as `solved`,monthname(Submitted) as `month` FROM LegalAidDirectView  WHERE $where AND  case_status='Resolved' and year(Submitted) = 2015 and month(Submitted) <= month(curdate()) group by monthname(Submitted) order by month(Submitted) asc";
			$solved=$query :: select ($sql);
			$solv = array();
                        while($solvrow = mysql_fetch_array($solved)){    
                            $solv[] = $solvrow;
                        }
			
			//end without solution
                        
                        $sql="SELECT count(record_id) as `endnotsolved`,monthname(Submitted) as `month` FROM LegalAidDirectView WHERE $where AND  case_status='End without solution' and year(Submitted) = 2015 and month(Submitted) <= month(curdate()) group by monthname(Submitted) order by month(Submitted) asc";
			$endnotsolved= $query :: select ($sql);
                        
                        
			$endnotsolv = array();
                        while($endnotsolvrow = mysql_fetch_array($endnotsolved)){    
                            $endnotsolv[] = $endnotsolvrow;
}
                      


//total disputes


//$sql="SELECT count(*) as `total`,case_status  FROM LegalAidDirectView WHERE year(Submitted) = 2015 and month(Submitted) <= month(curdate()) group by case_status asc";
$sql = "SELECT COUNT(case when case_status = 'Ongoing' THEN 1 END) AS 'Ongoing',COUNT( case when case_status = 'Resolved' THEN 1 END) AS 'Resolved',count(case when case_status = 'End without solution' THEN 1 END) AS 'END',count(case when case_status = 'Reffered' THEN 1 END) AS 'Reffered'  from LegalAidDirectView WHERE $where";
			$disputes= $query :: select ($sql);
                        $dispute = array();
                        while($disputerow = mysql_fetch_array($disputes)){    
                            $dispute[] = $disputerow;
                            
                            
}
  // total case type

$sql = "SELECT COUNT(CASE WHEN case_type = 'Child Maintainance' THEN 1 END) AS 'Child',COUNT(CASE WHEN case_type = 'Labour' THEN 1 END) AS 'Labour',COUNT(CASE WHEN case_type = 'Matrimonial' THEN 1 END) AS 'Matrimonial',COUNT(CASE WHEN case_type = 'Land' THEN 1 END) AS 'Land',COUNT(CASE WHEN case_type = 'Civil' THEN 1 END) AS 'Civil' FROM 
LegalAidDirectView WHERE $where";
$casetypes = $query :: select($sql);
$casetype = array();
while($casetyperow = mysql_fetch_array($casetypes)){
    
    $casetype[] = $casetyperow;
}


$sql = "SELECT count(case when gender = 'Male' Then 1 END) AS 'Male',count(case when gender = 'Female' Then 1 END) AS 'Female' from LegalAidDirectView WHERE $where";
$genderbased = $query :: select($sql);
$genderbase = array();
while($genderbaserow = mysql_fetch_array($genderbased)){
    
    $genderbase[] = $genderbaserow;
}


//Clients' gender distribution by case types of resolved disputes  
$sql = "SELECT case_type,count(case when gender = 'Male' Then 1 END) AS 'Male',count(case when gender = 'Female' Then 1 END) AS 'Female' from LegalAidDirectView  where $where AND case_type = 'Child Maintenance' and case_status='Resolved'";
$result = $query :: select($sql);
$childgenderbase = array();

while ($row = mysql_fetch_array($result)) {
    $childgenderbase[] = $row;
}

$sql = "SELECT case_type,count(case when gender = 'Male' Then 1 END) AS 'Male',count(case when gender = 'Female' Then 1 END) AS 'Female' from LegalAidDirectView  where $where AND case_type = 'GBV' and case_status='Resolved'";
$result = $query :: select($sql);
$gbvgenderbase = array();

while ($row = mysql_fetch_array($result)) {
    $gbvgenderbase[] = $row;
}

$sql = "SELECT case_type,count(case when gender = 'Male' Then 1 END) AS 'Male',count(case when gender = 'Female' Then 1 END) AS 'Female' from LegalAidDirectView  where $where AND case_type = 'Sexual Harrasment' and case_status='Resolved'";
$result = $query :: select($sql);
$sexgenderbase = array();

while ($row = mysql_fetch_array($result)) {
    $sexgenderbase[] = $row;
}


$sql = "SELECT case_type,count(case when gender = 'Male' Then 1 END) AS 'Male',count(case when gender = 'Female' Then 1 END) AS 'Female' from LegalAidDirectView  where $where AND case_type = 'Wife Beating' and case_status='Resolved'";
$result = $query :: select($sql);
$wifebeatinggenderbase = array();
while ($row = mysql_fetch_array($result)) {
    $wifebeatinggenderbase[] = $row;
}


$sql = "SELECT REPLACE(REPLACE(case_type,'Child Cus','Child Custody'),'child custody','Child Custody') as 'case_type',count(case when LegalAidDirectView.gender = 'Male' Then 1 END) AS 'Male',count(case when LegalAidDirectView.gender = 'Female' Then 1 END) AS 'Female' from LegalAidDirectView  WHERE   REPLACE(case_type,'Child Cus','child custody') LIKE '%Child Cus%' AND case_status = 'Resolved' AND $where group by REPLACE(REPLACE(case_type,'Child Cus','Child Custody'),'child custody','Child Custody')";
$result = $query :: select($sql);
$childcustodygenderbaseresolved = array();

while ($row = mysql_fetch_array($result)) {
    $childcustodygenderbaseresolved[] = $row;
}



$sql = "SELECT case_type,count(case when gender = 'Male' Then 1 END) AS 'Male',count(case when gender = 'Female' Then 1 END) AS 'Female' from LegalAidDirectView  where $where AND case_type = 'labour' and case_status='Resolved'";
$result = $query :: select($sql);
$labourgenderbase = array();
while ($row = mysql_fetch_array($result)) {
    $labourgenderbase[] = $row;
}

$sql = "SELECT case_type,count(case when gender = 'Male' Then 1 END) AS 'Male',count(case when gender = 'Female' Then 1 END) AS 'Female' from LegalAidDirectView  where $where AND case_type = 'Other' and case_status='Resolved'";
$result = $query :: select($sql);
$othergenderbase = array();
while ($row = mysql_fetch_array($result)) {
    $othergenderbase[] = $row;
}

$sql = "SELECT case_type,count(case when gender = 'Male' Then 1 END) AS 'Male',count(case when gender = 'Female' Then 1 END) AS 'Female' from LegalAidDirectView  where $where AND case_type = 'Rape' and case_status='Resolved'";
$result = $query :: select($sql);
$rapegenderbase = array();
while ($row = mysql_fetch_array($result)) {
    $rapegenderbase[] = $row;
}

$sql = "SELECT case_type,count(case when gender = 'Male' Then 1 END) AS 'Male',count(case when gender = 'Female' Then 1 END) AS 'Female' from LegalAidDirectView  where case_type = 'Civil' and case_status='Resolved' AND $where";
$result = $query :: select($sql);
$civilgenderbase = array();

while ($row = mysql_fetch_array($result)) {
    $civilgenderbase[] = $row;
}


$sql = "SELECT case_type,count(case when gender = 'Male' Then 1 END) AS 'Male',count(case when gender = 'Female' Then 1 END) AS 'Female' from LegalAidDirectView  where case_type = 'Gbv' and case_status='Resolved' AND $where";
$result = $query :: select($sql);
$gbvgenderbase = array();

while ($row = mysql_fetch_array($result)) {
    $gbvgenderbase[] = $row;
}

$sql = "SELECT case_type,count(case when gender = 'Male' Then 1 END) AS 'Male',count(case when gender = 'Female' Then 1 END) AS 'Female' from LegalAidDirectView  where case_type = 'Labour' and case_status='Resolved' AND $where";
$result = $query :: select($sql);
$labourgenderbase = array();

while ($row = mysql_fetch_array($result)) {
    $labourgenderbase[] = $row;
}


$sql = "SELECT case_type,count(case when gender = 'Male' Then 1 END) AS 'Male',count(case when gender = 'Female' Then 1 END) AS 'Female' from LegalAidDirectView  where case_type = 'Land' and case_status='Resolved' AND $where";
$result = $query :: select($sql);
$landgenderbase = array();

while ($row = mysql_fetch_array($result)) {
    $landgenderbase[] = $row;
}


$sql = "SELECT case_type,count(case when gender = 'Male' Then 1 END) AS 'Male',count(case when gender = 'Female' Then 1 END) AS 'Female' from LegalAidDirectView  where case_type = 'Matrimonial' and case_status='Resolved' AND $where";
$result = $query :: select($sql);
$matrimonialgenderbase = array();

while ($row = mysql_fetch_array($result)) {
    $matrimonialgenderbase[] = $row;
}



$sql = "SELECT case_type,count(case when gender = 'Male' Then 1 END) AS 'Male',count(case when gender = 'Female' Then 1 END) AS 'Female' from LegalAidDirectView WHERE $where  group by case_type";
$result = $query :: select($sql);
$casegenderbase = array();
$summale = "";
$sumfemale = "";
while ($row = mysql_fetch_array($result)) {
    $casegenderbase[] = $row;
}
foreach ($casegenderbase as $key => $value) {

    $summale +=$casegenderbase[$key]['Male'];
    $sumfemale += $casegenderbase[$key]['Female'];
}
$totmale = "";
$totfemale = "";


$sql = "SELECT distinct case_type as 'case_type' from LegalAidDirectView group by case_type";
$result = $query :: select($sql);
$distinctcasetype = array();
while($row == mysql_fetch_array($result)){
    
    $distinctcasetype[] = $row;
}

//foreach($distinctcasetype as $key){ echo  '"'.$key['case_type'].'"';}



$sql = "SELECT count(*) AS 'Total',COUNT(case when case_status = 'Ongoing' THEN 1 END) AS 'Ongoing',COUNT( case when case_status = 'Resolved' THEN 1 END) AS 'Resolved',count(case when case_status = 'End without solution' THEN 1 END) AS 'END',count(case when case_status = 'Reffered' THEN 1 END) AS 'Reffered'  from LegalAidDirectView WHERE $where";
$casestat = $query :: select($sql);
$casestatus = array();
while ($row = mysql_fetch_array($casestat)) {

    $casestatus[] = $row;
}
if($casestatus[0]['Ongoing'] > 0){
    
    $ongoingperc = round($casestatus[0]['Ongoing'] / $casestatus[0]['Total'] * 100);
}
else{
    
    $ongoingperc =0;
}
if($casestatus[0]['Resolved']>0){
$resolvedperc = round($casestatus[0]['Resolved'] / $casestatus[0]['Total'] * 100);}
else{
  $resolvedperc = 0;  
    
}

if($casestatus[0]['Reffered']>0){
    
    

$refferedperc = round($casestatus[0]['Reffered'] / $casestatus[0]['Total'] * 100);}
else{
    
    $refferedperc =0;
}
if($casestatus[0]['END']>0){
$endperc = round($casestatus[0]['END'] / $casestatus[0]['Total'] * 100);

}
else{
    
        $endperc = 0;

}



$sql = "SELECT SUM(Male + Female) As 'Total',SUM(Male) AS 'Male',SUM(Female) AS 'Female' from LegalEducationDirectView WHERE $where";
$edugenderbased = $query :: select($sql);
$edugenderbase = array();
while ($genderbaserow = mysql_fetch_array($edugenderbased)) {
    $edugenderbase[] = $genderbaserow;
}
$edumaleperc = round($edugenderbase[0]['Male']);
$edufemaleperc = round($edugenderbase[0]['Female']);
$sql = "SELECT count(*) AS 'Total',COUNT(case when case_status = 'Ongoing' THEN 1 END) AS 'Ongoing',COUNT( case when case_status = 'Resolved' THEN 1 END) AS 'Resolved',count(case when case_status = 'End without solution' THEN 1 END) AS 'END',count(case when case_status = 'Reffered' THEN 1 END) AS 'Reffered'  from LegalAidDirectView WHERE $where";
$result = $query :: select($sql);
$totcasestatus = array();
while ($row = mysql_fetch_array($result)) {

    $totcasestatus[] = $row;
}
$totongoingperc = round($totcasestatus[0]['Ongoing']);
$totresolvedperc = round($totcasestatus[0]['Resolved']);
$totrefferedperc = round($totcasestatus[0]['Reffered']);
$totendperc = round($totcasestatus[0]['END']);



$sql = "SELECT Count(*) As 'Total',COUNT(CASE WHEN source = 'USSD' THEN 1 END) AS 'Ussd',COUNT(case when source = 'android' THEN 1 END) AS 'android' from LegalAidDirectView WHERE $where";
$sourcebased = $query :: select($sql);
$sourcebase = array();
while ($row = mysql_fetch_array($sourcebased)) {
    $sourcebase[] = $row;
}
$ussdperc = round($sourcebase[0]['Ussd']);
$androidperc = round($sourcebase[0]['android']);


$sql = "SELECT COUNT(case WHEN gender = 'Male' THEN 1 END) AS 'MALE',COUNT(case WHEN gender = 'Female' THEN 1 END) AS 'Female' FROM LegalAidDirectView WHERE case_type <> '0' AND $where";

$result = $query :: select($sql);
$gbv = mysql_fetch_row($result);
$gbvmale = $gbv[0];
$gbvfemale = $gbv[1];


$sql = "SELECT COUNT(CASE WHEN case_type = 'Rape' THEN 1 END) AS 'Rape',COUNT(CASE WHEN case_type = 'Wife Battery' THEN 1 END) AS 'Wifebattery',
        COUNT(CASE WHEN case_type = 'Genital Mutilation' THEN 1 END) AS 'Genital',
        COUNT(CASE WHEN case_type = 'Sexual Slavery' THEN 1 END) AS 'Slavery',
        COUNT(CASE WHEN case_type = 'Sexual Assault' THEN 1 END) AS 'Assault',
        COUNT(CASE WHEN case_type = 'Cruelty' THEN 1 END) AS 'Cruelty' from LegalAidDirectView WHERE $where";
$result = $query :: select($sql);

$row            = mysql_fetch_array($result);
$rape           = $row['Rape'];
$wife_battery   = $row['Wifebattery'];
$genital        = $row['Genital'];
$slavery        = $row['Slavery'];
$assault        = $row['Assault'];
$cruelty        = $row['Cruelty'];


?>
