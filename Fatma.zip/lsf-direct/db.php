<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of db
 *
 * @author      Arun.Pariyanampatta
 * @description Database conncection
 */
//include('constants.php');
$link = mysql_connect("localhost", "root", "hhPG35Qk9aZt");
if (!$link) {
    die('Could not connect: ' . mysql_error());
}
mysql_select_db('lsf_platform');
?>
