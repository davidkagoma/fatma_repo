<?php
ob_start();
session_start();

include_once './includes/session.php';

include_once './includes/header.php';

include_once 'paralegalservice.php';
$title = "LSF | Edit Paralegal";
$pageContents = ob_get_contents();
$activePage = 'paralegal';
ob_end_clean();
echo str_replace('<!--TITLE-->', $title, $pageContents);
?>
<?php include 'includes/bottom_header_part.php'; ?>
<!--<div class="navbar-tools">
<?php
//include_once './includes/top.php';
?>
                    </div>
                    </div>    
                </div>-->
<!--                   <div class="main-container">
                <div class="navbar-content">
                    <div class="main-navigation navbar-collapse collapse">
<?php //include('includes/menu.php');  ?>
                    </div>
                   
                </div>
             </div>
<div class="main-content">-->
<!-- start: PANEL CONFIGURATION MODAL FORM -->
<div class="row">
    <div class="col-xs-12 col-sm-6 col-md-3" id="side_menu">
<?php
include('includes/side_menu.php');
?>
    </div>
    <div class="col-xs-12 col-sm-6 col-md-3"></div>
    <div class="col-xs-12 col-sm-6 col-md-9 " id="center_body">

<?php
foreach ($_SESSION['paralegal'] as $key => $value) {

    $zone = $_SESSION['paralegal'][$key]['zone_name'];
    $region = $_SESSION['paralegal'][$key]['region_name'];
    $status = $_SESSION['paralegal'][$key]['status'];
    $type = $_SESSION['paralegal'][$key]['Type'];
    $username = $_SESSION['paralegal'][$key]['username'];
    $password = $_SESSION['paralegal'][$key]['password'];
    $org = $_SESSION['paralegal'][$key]['organization'];
    $unit = $_SESSION['paralegal'][$key]['unit'];
}
echo "<script type='text/javascript'> var region  = '$region' </script>";
echo "<script type='text/javascript'> var org  = '$org' </script>";
echo "<script type='text/javascript'> var unit  = '$unit' </script>";
?>

        <!-- /.modal -->
        <!-- end: SPANEL CONFIGURATION MODAL FORM -->
        <div class="container">
            <!-- start: PAGE HEADER -->
            <div class="row">

            </div>
            <!-- end: PAGE HEADER -->
            <!-- start: PAGE CONTENT -->
            <div class="row">
                <div class="col-sm-12">
                    <div class="panel">
                        <div class="panel-body">
                            <h2><?php echo "Edit Paralegal"; ?></h2>
                            <hr>

                            <div id="result">


                            </div>


                            <div class="form-group">
                                <label class="col-sm-4 control-label" for="group-name">
                                    Name
                                </label>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <input  type="hidden" value="<?php echo $_SESSION['paralegal'][0]['paralegalid'] ?>" id="paralegalid" name="paralegalid">
                                        <input  type="hidden" value="<?php echo $_SESSION['paralegal'][0]['login_id'] ?>" id="loginid" name="loginid">
                                        <input type="text" name="name" id="name" value="<?php echo $_SESSION['paralegal'][0]['name']; ?>" class="form-control required">
                                        <label id="error_name" style="color: red;display:none">Name is Missing</label>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-4 control-label" id = "address" for="group-name">
                                    Address
                                </label>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <textarea  name="address" id="address" class="form-control required">
<?php echo $_SESSION['paralegal'][0]['address'] ?> 
                                        </textarea>   
                                        <label id="error_address" style="color: red;display:none">Address is Missing</label>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-4 control-label" for="group-name">
                                    Zones
                                </label>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <select id="zones" name="zones" class="form-control">

<?php foreach ($zones as $value) {
    if ($zone == $value['zone_name']) { ?>
                                                    <option selected="selected" value="<?php echo $value['id']; ?>"><?php echo $value['zone_name']; ?></option>
    <?php } else { ?>
                                                    <option value="<?php echo $value['id']; ?>"><?php echo $value['zone_name']; ?></option>
                                                <?php }
                                            } ?>
                                        </select>
                                        <label id="error_region" style="color: red;display:none">Region is Missing</label>
                                    </div>
                                </div>
                            </div>   
                            <div class="form-group">
                                <label class="col-sm-4 control-label" for="group-name">
                                    Region
                                </label>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <select id="region" name="region" class="form-control">

                                        </select>
                                        <label id="error_region" style="color: red;display:none">Region is Missing</label>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-4 control-label" for="group-name">
                                    District
                                </label>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <input type="text" name="district" id="district" class="form-control required" value="<?php echo $_SESSION['paralegal'][0]['district'] ?>">
                                        <label id="error_district" style="color: red;display:none">District is Missing</label>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-4 control-label" for="group-name">
                                    Ward
                                </label>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <input type="text" name="village" id="village" class="form-control required" value="<?php echo $_SESSION['paralegal'][0]['village'] ?>"> 
                                        <label id="error_village" style="color: red;display:none">Village is Missing</label>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-4 control-label" for="group-name">
                                    Mobile
                                </label>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <input type="text" name="mobile" id="mobile" class="form-control required" value="<?php echo $_SESSION['paralegal'][0]['msisdn'] ?>">
                                        <label id="error_mobile" style="color: red;display:none">Mobile is Missing</label>
                                        <label id="errmsg" style="color: red;display:block"></label>
                                    </div>
                                </div>
                            </div>


                            <div class="form-group">
                                <label class="col-sm-4 control-label" for="group-name">
                                    Organization
                                </label>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <select id="organization" class="form-control">

                                        </select>
                                        <label id="error_organization" style="color: red;display:none">Mobile is Missing</label>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-4 control-label" for="group-name">
                                    Units
                                </label>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <select id="units" class="form-control">

                                        </select>
                                        <label id="error_units" style="color: red;display:none">Mobile is Missing</label>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-4 control-label" for="group-name">
                                    Username
                                </label>
                                <div class="col-sm-6">
                                    <div class="form-group">
<?php if ($username == '') { ?>

                                            <input type="text" name="uname"  id="uname" class="form-control " value="<?php echo $username ?>">
                                        <?php } else { ?>
                                            <input type="text" name="uname" readonly  id="uname" class="form-control " value="<?php echo $username ?>">
                                            <label id="error_uname" style="color: red;display:none">User name is missing</label>
                                        <?php } ?>
                                        <label id="errmsg" style="color: red;display:block"></label>
                                    </div>
                                </div>
                            </div>



                            <div class="form-group">
                                <label class="col-sm-4 control-label" for="group-name">
                                    Password
                                </label>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <input type="password" name="password" id="password" class="form-control" value="">
                                        <label id="error_password" style="color: red;display:none">Password is missing</label>
                                        <label id="errmsg" style="color: red;display:block"></label>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-4 control-label" for="group-name">
                                    Type
                                </label>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <select id="type" name="type" id="type" class="form-control">
<?php if ($type == 'Paralegal Admin') { ?>
                                                <option selected = 'selected' value="Paralegal Admin">Paralegal Admin</option>
                                                <option value="Paralegal User">Paralegal User</option>
                                            <?php } else { ?>
                                                <option  value="Paralegal Admin">Paralegal Admin</option>
                                                <option selected='selected' value="Paralegal User">Paralegal User</option>
                                            <?php } ?>
                                        </select>
                                    </div>
                                </div>
                            </div>


                            <div class="form-group">
                                <label class="col-sm-4 control-label" for="group-name">
                                    Status
                                </label>
                                <div class="col-sm-6">
                                    <select id ="status" class="form-control">
<?php if ($status == "Active") { ?>
                                            <option value="1" selected="selected">Active</option>
                                            <option value="0">InActive</option>
                                        <?php } else { ?>
                                            <option value="1">Active</option>
                                            <option value="0" selected="selected">InActive</option>
                                        <?php } ?>
                                    </select>
                                </div>
                            </div>
                            

                            <div class="form-group">
                                <label class="col-sm-4 control-label" for="crete">
                                </label>
                                
                                <div id="formsubmit" class="col-sm-6">
                                    <div class="form-group">
                                        <a href="#" id="canc">
                                            <button id="cancel" type="button" class="btn btn-default">
                                                Reset <i class="icon-circle-arrow-cross"></i>
                                            </button></a>
                                        <button type="submit" name="updateparalegal" id="updateparalegal" class="btn btn-primary">
                                            Save <i class="icon-circle-arrow-right"></i>
                                        </button></div>
                                </div>
                            </div>	
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> </div>
<?php
include_once './includes/footer.php'
?>
