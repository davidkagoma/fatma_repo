<?php
require_once 'query.php';
//include_once './includes/session.php';
require_once './includes/Excel.php';
 require_once(dirname(__FILE__).'/html2pdf/html2pdf.class.php');

$objPHPExcel = new PHPExcel();


if($_POST['report']){
    
    
    
    session_start();
    if($_SESSION['type']=='super admin'){
    
    $where = "1=1";
    
}

else{
    
    $sql = "SELECT unit_id from paralegals where login_id = {$_SESSION['loginid']}";
    $result = $query :: select($sql);
    $row = mysql_fetch_array($result);
    $unitid = $row['unit_id'];
    
    $where = "unit_id = {$unitid}";
}

   $type =  $_POST['report'];
   
   
   if(isset($_POST['export'])){
       if($_POST['export']=='Export AS Excel'){
       $downloadtype = "export";
       }
      
   }
 
 else{
     
       $downloadtype = 'exportpdf';
 }

 
 if($type=="SMS-LOG"){
     $sql = "SELECT * FROM smslog";
     $result = $query::select($sql);
     $sms = array();
     while($row=mysql_fetch_array($result)){
         $sms[]  = $row;

     
}
      if($downloadtype=="export"){    
          $maxrow = count($sms)+1;
$rowNumberH = 1;
$colH = 'A';
$objPHPExcel->getActiveSheet()->setCellValue('A1','Mobile');
$objPHPExcel->getActiveSheet()->setCellValue('B1','Content');
$objPHPExcel->getActiveSheet()->setCellValue('C1','Date');
for($i=0;$i<count($sms);$i++){
$col = $i+2;
 $objPHPExcel->getActiveSheet()->setCellValue('A'.$col,$sms[$i]['msisdn']);
         $objPHPExcel->getActiveSheet()->setCellValue('B'.$col,$sms[$i]['sms']);
         $objPHPExcel->getActiveSheet()->setCellValue('C'.$col,$sms[$i]['date']);
    
}
$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel,'Excel5');
        header('Content-Type: application/vnd.ms-excel');
    header('Content-Disposition: attachment;filename="Report-'.$type.'.xls"');
    header('Cache-Control: max-age=0');
    $objWriter->save('php://output');
    exit();

}
else{
$content = "
<page backcolor = 'white'>
<div class='cntr' style='margin-top:350px;margin-left:350px'>   
    <br>
    <img src='assets/images/logoLSF.png'/>
    <h1 style='float:left'>{$type}</h1>
    </div>
</page>";
   $content .='<page backcolor = "white" width="auto">
    <table  width="auto" height="auto" style="margin:10px;" border="1px">
    <thead>
                    <tr>
                        <th width="33.5%">Mobile</th>
                        <th width="33.5%">Message</th>
                    </tr></thead><tbody>';
           for($i=0;$i<count($sms);$i++){
               $mobile = $sms[$i]['msisdn'];
               $sms    = $sms[$i]['sms'];
                 $content .=<<<EOD
<tr bgcolor="#EAF8FF">
<td>
$mobile
</td>
<td>
$sms
</td>
</tr>
EOD
                         ;
           }
                  $content .= '</tbody></table>
</page>';
   
    $html2pdf = new HTML2PDF('P','A4','en');
    $html2pdf->WriteHTML($content);
    $html2pdf->Output('Report-'.$type.'.pdf');
     header('Content-Type: application/pdf');
    header('Content-Disposition: attachment;filename=Report-'.$type.'.pdf');
}
exit;
}
 if($type=="Paralegal"){
     
     
     
     $sql = "SELECT * FROM paralegalview where $where";
     
     $result = $query::select($sql);
     $paralegal = array();
     while($row=mysql_fetch_array($result)){
         
         $paralegal[] = $row;
     }
     
    // if(isset($_POST['export'])){
         
         if($downloadtype=="export"){
          $maxrow = count($paralegal)+1;
$rowNumberH = 1;
$colH = 'A';
   
   
$objPHPExcel->getActiveSheet()->setCellValue('A1','Name');
$objPHPExcel->getActiveSheet()->setCellValue('B1','Region');
$objPHPExcel->getActiveSheet()->setCellValue('C1','Unit');
$objPHPExcel->getActiveSheet()->setCellValue('D1','Mobile');
$objPHPExcel->getActiveSheet()->setCellValue('E1','User Type');
$objPHPExcel->getActiveSheet()->setCellValue('F1','Status');
for($i=0;$i<count($paralegal);$i++){
    $col = $i+2;
         $objPHPExcel->getActiveSheet()->setCellValue('A'.$col,$paralegal[$i]['name']);
         $objPHPExcel->getActiveSheet()->setCellValue('B'.$col,$paralegal[$i]['region_name']);
         $objPHPExcel->getActiveSheet()->setCellValue('C'.$col,$paralegal[$i]['unit']);
         $objPHPExcel->getActiveSheet()->setCellValue('D'.$col,$paralegal[$i]['msisdn']);         
         $objPHPExcel->getActiveSheet()->setCellValue('E'.$col,$paralegal[$i]['Type']);
         $objPHPExcel->getActiveSheet()->setCellValue('F'.$col,$paralegal[$i]['status']);
        
     
    }
    $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel,'Excel5');
        header('Content-Type: application/vnd.ms-excel');
    header('Content-Disposition: attachment;filename="Report-'.$type.'.xls"');
    header('Cache-Control: max-age=0');
    $objWriter->save('php://output');
    exit();

         
         
         }      
         else{
   $content = "
<page backcolor = 'white'>
<div class='cntr' style='margin-top:350px;margin-left:350px'>
    
    <br>
    <img src='assets/images/logoLSF.png'/>
    <h1 style='float:left'>{$type}</h1>
    </div>
</page>";
   
   $content .='<page backcolor = "white" width="auto">
    <table  width="auto" height="auto" style="margin:10px;" border="1px">
    <thead>
                    <tr>
                        <th width="12.5%">Name On</th>
                        <th width="12.5%">Region</th>
                        <th width="12.5%">Unit</th>
                        <th width="12.5%">Msisdn</th>
                        <th width="12.5%">Type</th>
                        <th width="12.5%">Status</th>
                    </tr></thead><tbody>';
   
           for($i=0;$i<count($paralegal);$i++){
              
               $name = $paralegal[$i]['name'];
               $region = $paralegal[$i]['region_name'];
               $unit = $paralegal[$i]['unit'];
               $mobile= $paralegal[$i]['msisdn'];
               $type= $paralegal[$i]['Type'];
               $status= $paralegal[$i]['status'];;
               
                 $content .=<<<EOD
<tr bgcolor="#EAF8FF">
<td>
$name
</td>
<td>
$region
</td>
<td>
$unit
</td>
<td>
$mobile
</td>
<td>
$type
</td>
<td>
$status
</td>


</tr>
EOD
                         ;
           }
                  $content .= '</tbody></table>
</page>';
   
   $html2pdf = new HTML2PDF('P','A4','en');
    $html2pdf->WriteHTML($content);
    $html2pdf->Output('Report-'.$type.'.pdf');
     header('Content-Type: application/pdf');
    header('Content-Disposition: attachment;filename=Report-'.$type.'.pdf');
    
}
     exit;        
         
    // }
 }
 
    
       if($type == "Legal-Education-Delayed"){
     
     $sql = "SELECT * from LegalEducationFilterAcceptedView WHERE $where AND date(Submitted) <date(accepted_at)";
     $result = $query :: select($sql);
        $education = array();
        while($row = mysql_fetch_array($result)){   
            $education[] = $row;
}
     if(isset($_POST['export'])){
         if($downloadtype=="export"){
         $maxrow = count($education)+1;
$rowNumberH = 1;
$colH = 'A';
   
   
$objPHPExcel->getActiveSheet()->setCellValue('A1','Date of Submission');
$objPHPExcel->getActiveSheet()->setCellValue('B1','Mobile');
$objPHPExcel->getActiveSheet()->setCellValue('C1','Submitted By');
$objPHPExcel->getActiveSheet()->setCellValue('D1','Unit');
$objPHPExcel->getActiveSheet()->setCellValue('E1','Event Date');
$objPHPExcel->getActiveSheet()->setCellValue('F1','Event Type');
$objPHPExcel->getActiveSheet()->setCellValue('G1','Duration');
$objPHPExcel->getActiveSheet()->setCellValue('H1','No Of Male');
$objPHPExcel->getActiveSheet()->setCellValue('I1','No Of Female');






for($i=0;$i<count($education);$i++){
    $col = $i+2;
         $objPHPExcel->getActiveSheet()->setCellValue('A'.$col,$education[$i]['Submitted']);
         $objPHPExcel->getActiveSheet()->setCellValue('B'.$col,$education[$i]['phone_number']);
         $objPHPExcel->getActiveSheet()->setCellValue('C'.$col,$education[$i]['name']);
         $objPHPExcel->getActiveSheet()->setCellValue('D'.$col,$education[$i]['unit_name']);         
         $objPHPExcel->getActiveSheet()->setCellValue('E'.$col,$education[$i]['EventDate']);
         $objPHPExcel->getActiveSheet()->setCellValue('F'.$col,$education[$i]['event_type']);
         $objPHPExcel->getActiveSheet()->setCellValue('G'.$col,$education[$i]['duration']);
         $objPHPExcel->getActiveSheet()->setCellValue('H'.$col,$education[$i]['Male']);
         $objPHPExcel->getActiveSheet()->setCellValue('I'.$col,$education[$i]['Female']);
     
    }
    $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel,'Excel5');
        header('Content-Type: application/vnd.ms-excel');
    header('Content-Disposition: attachment;filename="Report-'.$type.'.xls"');
    header('Cache-Control: max-age=0');
    $objWriter->save('php://output');
    exit();

         
         
         }      
         
         
     
     else{
   $content = "
<page backcolor = 'white'>
<div class='cntr' style='margin-top:350px;margin-left:350px'>
    
    <br>
    <img src='assets/images/logoLSF.png'/>
    <h1 style='float:left'>{$type}</h1>
    </div>
</page>";
   
   $content .='<page backcolor = "white" width="auto">
    <table  width="auto" height="auto" style="margin:10px;" border="1px">
    <thead>
                    <tr>
                        <th width="12.5%">Submitted On</th>
                        <th width="12.5%">Mobile</th>
                        <th width="12.5%">Submitted By</th>
                        <th width="12.5%">Unit</th>
                        <th width="12.5%">Event Date </th>
                        <th width="12.5%">Event Type</th>
                        <th width="12.5%">Duration</th>
                        <th width="12.5%">Male</th>
                        <th width="12.5%">Female</th>
                    </tr></thead><tbody>';
   
           for($i=0;$i<count($education);$i++){
               $time = date($education[$i]['Submitted']); 
               $time=strtotime($time);
               $time = date("Y-m-d",$time);
               
               $mobile = $education[$i]['phone_number'];
               $name = $education[$i]['name'];
               $unit = $education[$i]['unit_name'];
               $event_date= $education[$i]['EventDate'];
               $event_type= $education[$i]['event_type'];
               $duration= $education[$i]['duration'];
               $male= $education[$i]['Male'];
               $female= $education[$i]['Female'];
                 $content .=<<<EOD
<tr bgcolor="#EAF8FF">
<td>
$time
</td>
<td>
$mobile
</td>
<td>
$name
</td>
<td>
$unit
</td>
<td>
$event_date
</td>
<td>
$event_type
</td>
<td>
$duration
</td>
<td>
$male
</td>
<td>
$female
</td>

</tr>
EOD
                         ;
           }
                  $content .= '</tbody></table>
</page>';
   
   $html2pdf = new HTML2PDF('P','A4','en');
    $html2pdf->WriteHTML($content);
    $html2pdf->Output('Report-'.$type.'.pdf');
     header('Content-Type: application/pdf');
    header('Content-Disposition: attachment;filename=Report-'.$type.'.pdf');
    
}
     exit;
     }
 }
 
 
 
 if($type == "Legal-Education-Declined"){
     
     $sql = "SELECT * from LegalEducationFilterDeclinedView WHERE $where";
     $result = $query :: select($sql);
        $education = array();
        while($row = mysql_fetch_array($result)){   
            $education[] = $row;
}
     if(isset($_POST['export'])){
         if($downloadtype=="export"){
         $maxrow = count($education)+1;
$rowNumberH = 1;
$colH = 'A';
   
   
$objPHPExcel->getActiveSheet()->setCellValue('A1','Date of Submission');
$objPHPExcel->getActiveSheet()->setCellValue('B1','Mobile');
$objPHPExcel->getActiveSheet()->setCellValue('C1','Submitted By');
$objPHPExcel->getActiveSheet()->setCellValue('D1','Unit');
$objPHPExcel->getActiveSheet()->setCellValue('E1','Event Date');
$objPHPExcel->getActiveSheet()->setCellValue('F1','Event Type');
$objPHPExcel->getActiveSheet()->setCellValue('G1','Duration');
$objPHPExcel->getActiveSheet()->setCellValue('H1','No Of Male');
$objPHPExcel->getActiveSheet()->setCellValue('I1','No Of Female');






for($i=0;$i<count($education);$i++){
    $col = $i+2;
         $objPHPExcel->getActiveSheet()->setCellValue('A'.$col,$education[$i]['Submitted']);
         $objPHPExcel->getActiveSheet()->setCellValue('B'.$col,$education[$i]['phone_number']);
         $objPHPExcel->getActiveSheet()->setCellValue('C'.$col,$education[$i]['name']);
         $objPHPExcel->getActiveSheet()->setCellValue('D'.$col,$education[$i]['unit_name']);         
         $objPHPExcel->getActiveSheet()->setCellValue('E'.$col,$education[$i]['EventDate']);
         $objPHPExcel->getActiveSheet()->setCellValue('F'.$col,$education[$i]['event_type']);
         $objPHPExcel->getActiveSheet()->setCellValue('G'.$col,$education[$i]['duration']);
         $objPHPExcel->getActiveSheet()->setCellValue('H'.$col,$education[$i]['Male']);
         $objPHPExcel->getActiveSheet()->setCellValue('I'.$col,$education[$i]['Female']);
     
    }
    $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel,'Excel5');
        header('Content-Type: application/vnd.ms-excel');
    header('Content-Disposition: attachment;filename="Report-'.$type.'.xls"');
    header('Cache-Control: max-age=0');
    $objWriter->save('php://output');
    exit();

         
         
         }
         
         
     
     else{
   $content = "
<page backcolor = 'white'>
<div class='cntr' style='margin-top:350px;margin-left:350px'>
    
    <br>
    <img src='assets/images/logoLSF.png'/>
    <h1 style='float:left'>{$type}</h1>
    </div>
</page>";
   
   $content .='<page backcolor = "white" width="auto">
    <table  width="auto" height="auto" style="margin:10px;" border="1px">
    <thead>
                    <tr>
                        <th width="12.5%">Submitted On</th>
                        <th width="12.5%">Mobile</th>
                        <th width="12.5%">Submitted By</th>
                        <th width="12.5%">Unit</th>
                        <th width="12.5%">Event Date </th>
                        <th width="12.5%">Event Type</th>
                        <th width="12.5%">Duration</th>
                        <th width="12.5%">Male</th>
                        <th width="12.5%">Female</th>
                    </tr></thead><tbody>';
   
           for($i=0;$i<count($education);$i++){
               $time = date($education[$i]['Submitted']); 
               $time=strtotime($time);
               $time = date("Y-m-d",$time);
               
               $mobile = $education[$i]['phone_number'];
               $name = $education[$i]['name'];
               $unit = $education[$i]['unit_name'];
               $event_date= $education[$i]['EventDate'];
               $event_type= $education[$i]['event_type'];
               $duration= $education[$i]['duration'];
               $male= $education[$i]['Male'];
               $female= $education[$i]['Female'];
                 $content .=<<<EOD
<tr bgcolor="#EAF8FF">
<td>
$time
</td>
<td>
$mobile
</td>
<td>
$name
</td>
<td>
$unit
</td>
<td>
$event_date
</td>
<td>
$event_type
</td>
<td>
$duration
</td>
<td>
$male
</td>
<td>
$female
</td>

</tr>
EOD
                         ;
           }
                  $content .= '</tbody></table>
</page>';
   
   $html2pdf = new HTML2PDF('P','A4','en');
    $html2pdf->WriteHTML($content);
    $html2pdf->Output('Report-'.$type.'.pdf');
     header('Content-Type: application/pdf');
    header('Content-Disposition: attachment;filename=Report-'.$type.'.pdf');
    
}

     exit;
     }
     }
 

 
 if($type == "Legal-Education-Direct"){
     
     $sql = "SELECT * from LegalEducationDirectView WHERE $where";
     
     $result = $query :: select($sql);
     
        $education = array();
        while($row = mysql_fetch_array($result)){   
            $education[] = $row;
}
     if(isset($_POST['export'])){
         if($downloadtype=="export"){
         $maxrow = count($education)+1;
$rowNumberH = 1;
$colH = 'A';
   
   
$objPHPExcel->getActiveSheet()->setCellValue('A1','Date of Submission');
$objPHPExcel->getActiveSheet()->setCellValue('B1','Mobile');
$objPHPExcel->getActiveSheet()->setCellValue('C1','Submitted By');
$objPHPExcel->getActiveSheet()->setCellValue('D1','Unit');
$objPHPExcel->getActiveSheet()->setCellValue('E1','Event Date');
$objPHPExcel->getActiveSheet()->setCellValue('F1','Event Type');
$objPHPExcel->getActiveSheet()->setCellValue('G1','Duration');
$objPHPExcel->getActiveSheet()->setCellValue('H1','No Of Male');
$objPHPExcel->getActiveSheet()->setCellValue('I1','No Of Female');






for($i=0;$i<count($education);$i++){
    $col = $i+2;
         $objPHPExcel->getActiveSheet()->setCellValue('A'.$col,$education[$i]['Submitted']);
         $objPHPExcel->getActiveSheet()->setCellValue('B'.$col,$education[$i]['phone_number']);
         $objPHPExcel->getActiveSheet()->setCellValue('C'.$col,$education[$i]['name']);
         $objPHPExcel->getActiveSheet()->setCellValue('D'.$col,$education[$i]['unit_name']);         
         $objPHPExcel->getActiveSheet()->setCellValue('E'.$col,$education[$i]['EventDate']);
         $objPHPExcel->getActiveSheet()->setCellValue('F'.$col,$education[$i]['event_type']);
         $objPHPExcel->getActiveSheet()->setCellValue('G'.$col,$education[$i]['duration']);
         $objPHPExcel->getActiveSheet()->setCellValue('H'.$col,$education[$i]['Male']);
         $objPHPExcel->getActiveSheet()->setCellValue('I'.$col,$education[$i]['Female']);
     
    }
    $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel,'Excel5');
        header('Content-Type: application/vnd.ms-excel');
    header('Content-Disposition: attachment;filename="Report-'.$type.'.xls"');
    header('Cache-Control: max-age=0');
    $objWriter->save('php://output');
    exit();

         
         
         
         }
         
     }
     else{
   $content = "
<page backcolor = 'white'>
<div class='cntr' style='margin-top:350px;margin-left:350px'>
    
    <br>
    <img src='assets/images/logoLSF.png'/>
    <h1 style='float:left'>{$type}</h1>
    </div>
</page>";
   
   $content .='<page backcolor = "white" width="auto">
    <table  width="auto" height="auto" style="margin:10px;" border="1px">
    <thead>
                    <tr>
                        <th width="12.5%">Submitted On</th>
                        <th width="12.5%">Mobile</th>
                        <th width="12.5%">Submitted By</th>
                        <th width="12.5%">Unit</th>
                        <th width="12.5%">Event Date </th>
                        <th width="12.5%">Event Type</th>
                        <th width="12.5%">Duration</th>
                        <th width="12.5%">Male</th>
                        <th width="12.5%">Female</th>
                    </tr></thead><tbody>';
   
           for($i=0;$i<count($education);$i++){
               $time = date($education[$i]['Submitted']); 
               $time=strtotime($time);
               $time = date("Y-m-d",$time);
               
               $mobile = $education[$i]['phone_number'];
               $name = $education[$i]['name'];
               $unit = $education[$i]['unit_name'];
               $event_date= $education[$i]['EventDate'];
               $event_type= $education[$i]['event_type'];
               $duration= $education[$i]['duration'];
               $male= $education[$i]['Male'];
               $female= $education[$i]['Female'];
                 $content .=<<<EOD
<tr bgcolor="#EAF8FF">
<td>
$time
</td>
<td>
$mobile
</td>
<td>
$name
</td>
<td>
$unit
</td>
<td>
$event_date
</td>
<td>
$event_type
</td>
<td>
$duration
</td>
<td>
$male
</td>
<td>
$female
</td>

</tr>
EOD
                         ;
           }
                  $content .= '</tbody></table>
</page>';
   
   $html2pdf = new HTML2PDF('P','A4','en');
    $html2pdf->WriteHTML($content);
    $html2pdf->Output('Report-'.$type.'.pdf');
     header('Content-Type: application/pdf');
    header('Content-Disposition: attachment;filename=Report-'.$type.'.pdf');
    
}
     exit;
     
 }

 
 
    
     if($type == "Legal-Education-Accepted"){
     
     $sql = "SELECT * from LegalEducationFilterAcceptedView WHERE $where";
     $result = $query :: select($sql);
        $education = array();
        while($row = mysql_fetch_array($result)){   
            $education[] = $row;
}
     if(isset($_POST['export'])){
         if($downloadtype=="export"){
         $maxrow = count($education)+1;
$rowNumberH = 1;
$colH = 'A';
   
   
$objPHPExcel->getActiveSheet()->setCellValue('A1','Date of Submission');
$objPHPExcel->getActiveSheet()->setCellValue('B1','Mobile');
$objPHPExcel->getActiveSheet()->setCellValue('C1','Submitted By');
$objPHPExcel->getActiveSheet()->setCellValue('D1','Unit');
$objPHPExcel->getActiveSheet()->setCellValue('E1','Event Date');
$objPHPExcel->getActiveSheet()->setCellValue('F1','Event Type');
$objPHPExcel->getActiveSheet()->setCellValue('G1','Duration');
$objPHPExcel->getActiveSheet()->setCellValue('H1','No Of Male');
$objPHPExcel->getActiveSheet()->setCellValue('I1','No Of Female');






for($i=0;$i<count($education);$i++){
    $col = $i+2;
         $objPHPExcel->getActiveSheet()->setCellValue('A'.$col,$education[$i]['Submitted']);
         $objPHPExcel->getActiveSheet()->setCellValue('B'.$col,$education[$i]['phone_number']);
         $objPHPExcel->getActiveSheet()->setCellValue('C'.$col,$education[$i]['name']);
         $objPHPExcel->getActiveSheet()->setCellValue('D'.$col,$education[$i]['unit_name']);         
         $objPHPExcel->getActiveSheet()->setCellValue('E'.$col,$education[$i]['EventDate']);
         $objPHPExcel->getActiveSheet()->setCellValue('F'.$col,$education[$i]['event_type']);
         $objPHPExcel->getActiveSheet()->setCellValue('G'.$col,$education[$i]['duration']);
         $objPHPExcel->getActiveSheet()->setCellValue('H'.$col,$education[$i]['Male']);
         $objPHPExcel->getActiveSheet()->setCellValue('I'.$col,$education[$i]['Female']);
     
    }
    $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel,'Excel5');
        header('Content-Type: application/vnd.ms-excel');
    header('Content-Disposition: attachment;filename="Report-'.$type.'.xls"');
    header('Cache-Control: max-age=0');
    $objWriter->save('php://output');
    exit();

         
         
         
         
         
     }
     else{
   $content = "
<page backcolor = 'white'>
<div class='cntr' style='margin-top:350px;margin-left:350px'>
    
    <br>
    <img src='assets/images/logoLSF.png'/>
    <h1 style='float:left'>{$type}</h1>
    </div>
</page>";
   
   $content .='<page backcolor = "white" width="auto">
    <table  width="auto" height="auto" style="margin:10px;" border="1px">
    <thead>
                    <tr>
                        <th width="12.5%">Submitted On</th>
                        <th width="12.5%">Mobile</th>
                        <th width="12.5%">Submitted By</th>
                        <th width="12.5%">Unit</th>
                        <th width="12.5%">Event Date </th>
                        <th width="12.5%">Event Type</th>
                        <th width="12.5%">Duration</th>
                        <th width="12.5%">Male</th>
                        <th width="12.5%">Female</th>
                    </tr></thead><tbody>';
   
           for($i=0;$i<count($education);$i++){
               $time = date($education[$i]['Submitted']); 
               $time=strtotime($time);
               $time = date("Y-m-d",$time);
               
               $mobile = $education[$i]['phone_number'];
               $name = $education[$i]['name'];
               $unit = $education[$i]['unit_name'];
               $event_date= $education[$i]['EventDate'];
               $event_type= $education[$i]['event_type'];
               $duration= $education[$i]['duration'];
               $male= $education[$i]['Male'];
               $female= $education[$i]['Female'];
                 $content .=<<<EOD
<tr bgcolor="#EAF8FF">
<td>
$time
</td>
<td>
$mobile
</td>
<td>
$name
</td>
<td>
$unit
</td>
<td>
$event_date
</td>
<td>
$event_type
</td>
<td>
$duration
</td>
<td>
$male
</td>
<td>
$female
</td>

</tr>
EOD
                         ;
           }
                  $content .= '</tbody></table>
</page>';
   
   $html2pdf = new HTML2PDF('P','A4','en');
    $html2pdf->WriteHTML($content);
    $html2pdf->Output('Report-'.$type.'.pdf');
     header('Content-Type: application/pdf');
    header('Content-Disposition: attachment;filename=Report-'.$type.'.pdf');
    
}
     exit;
     }
 }
    
    
    if($type=="Legal-Aid-Declined"){
       
       $sql = "SELECT * from LegalAidFilterDeclinedView WHERE $where";
       
   }
    
    if($type=="Legal-Aid-Direct"){
       
       $sql = "SELECT * from LegalAidDirectView WHERE $where";
       
   } 
    
   if($type=="Legal-Aid-Pending"){
       
       $sql = "SELECT * from LegalAidFilterPendingView WHERE $where";
       
   } 

 if($type=='Legal-Aid-Delayed'){
        
         $sql = "SELECT * from LegalAidDirectView where  $where AND date(Submitted) < date(accepted_at) ";
        
    }   
   
   
if($type=="Legal-Aid-Other"){

$sql = "SELECT * from LegalAidDirectView where case_type = 'Other' AND $where";


}

if($type=="Legal-Aid-Sexual-Harrasment"){

$sql = "SELECT * from LegalAidDirectView where case_type = 'Sexual Harrasment' AND $where";

}
if($type=="Legal-Aid-Rape"){
    
    $sql = "SELECT * from LegalAidDirectView where case_type = 'Rape' AND $where";
}
if($type=="Legal-Aid-Criminal"){

 $sql = "SELECT * from LegalAidDirectView where case_type = 'Criminal' AND $where";

}

if($type=="Legal-Aid-Child-Maintenance"){

 $sql = "SELECT * from LegalAidDirectView where case_type = 'Child Maintenance' AND $where";

}

if($type=="Legal-Aid-Civil"){
$sql = "SELECT * from LegalAidDirectView where case_type = 'Civil' AND $where";

}

if($type == "Legal-Aid-Child-Custody"){
       
       $sql = "SELECT * from LegalAidDirectView where case_type = 'child custody' AND $where";
       
   }
   if($type == "Legal-Aid-Child Maintenance"){
       
       $sql = "SELECT * from LegalAidDirectView  where case_type = 'Child Maintainance'AND $where";
   }
   

   
   if($type == "Legal-Aid-GBV"){
       
       $sql = "SELECT * from LegalAidDirectView where case_type = 'GBV' AND $where";
   }
   
    if($type == "Legal-Aid-USSD"){
       
       $sql = "SELECT * from LegalAidDirectView where source = 'USSD' AND $where";
       
   }
   
   if($type == "Legal-Aid-Android"){
       
       $sql = "SELECT * from LegalAidDirectView where source = 'Android' AND $where";
   }
   if($type == "Legal-Aid-Resolved"){
       
       $sql = "SELECT * from LegalAidDirectView where case_status = 'Resolved' AND $where";
   }
    if($type == "Legal-Aid-Referred"){
       
       $sql = "SELECT * from LegalAidDirectView where case_status = 'Reffered' AND $where";
   }
   
     if($type == "Legal-Aid-Ongoing"){
       
       $sql = "SELECT * from LegalAidDirectView where case_status = 'Ongoing' AND $where";
   }
    if($type == "Legal-Aid-End without solution"){
       
       $sql = "SELECT * from LegalAidDirectView where case_status = 'End without solution' AND $where";
   }
   if($type == "Legal-Aid-Land"){
       
       $sql = "SELECT * from LegalAidDirectView  where case_type = 'Land' AND $where";
   }
   if($type == "Legal-Aid-Labour"){
       
       $sql = "SELECT * from LegalAidDirectView where case_type = 'Labour' AND $where";
   }
   
   if($type == "Legal-Aid-Matrimonial"){
       
       $sql = "SELECT * from LegalAidDirectView where case_type = 'Matrimonial' AND $where";
   }
   if($type == "Legal-Aid-Male"){
       $sql = "SELECT * from LegalAidDirectView where gender = 'Male' AND $where";
   }
   
   if($type == "Legal-Aid-Wife-Beating"){
       $sql = "SELECT * from LegalAidDirectView where case_type like '%Wife Beating%' AND $where";
   }
   
   if($type == "Legal-Aid-Female"){
       $sql = "SELECT * from LegalAidDirectView where gender = 'Female' AND $where";
   }
   $result = $query :: select($sql);
        $genderbase = array();
        while($row = mysql_fetch_array($result)){   
            $genderbase[] = $row;
}

if(isset($_POST['export'])){
    
    if($downloadtype=="export"){
$maxrow = count($genderbase)+1;
$rowNumberH = 1;
$colH = 'A';
   
   
$objPHPExcel->getActiveSheet()->setCellValue('A1','Date of Submission');
$objPHPExcel->getActiveSheet()->setCellValue('B1','Mobile');
$objPHPExcel->getActiveSheet()->setCellValue('C1','Submitted By');
$objPHPExcel->getActiveSheet()->setCellValue('D1','Unit');
$objPHPExcel->getActiveSheet()->setCellValue('E1','Gender');
$objPHPExcel->getActiveSheet()->setCellValue('F1','Age');
$objPHPExcel->getActiveSheet()->setCellValue('G1','Education');
$objPHPExcel->getActiveSheet()->setCellValue('H1','Marital Status');
$objPHPExcel->getActiveSheet()->setCellValue('I1','Case Type');
$objPHPExcel->getActiveSheet()->setCellValue('J1','Case Status');





for($i=0;$i<count($genderbase);$i++){
    $col = $i+2;
         $objPHPExcel->getActiveSheet()->setCellValue('A'.$col,$genderbase[$i]['Submitted']);
         $objPHPExcel->getActiveSheet()->setCellValue('B'.$col,$genderbase[$i]['phone_number']);
         $objPHPExcel->getActiveSheet()->setCellValue('C'.$col,$genderbase[$i]['name']);
         $objPHPExcel->getActiveSheet()->setCellValue('D'.$col,$genderbase[$i]['unit_name']);         
         $objPHPExcel->getActiveSheet()->setCellValue('E'.$col,$genderbase[$i]['gender']);
         $objPHPExcel->getActiveSheet()->setCellValue('F'.$col,$genderbase[$i]['age']);
         $objPHPExcel->getActiveSheet()->setCellValue('G'.$col,$genderbase[$i]['education']);
         $objPHPExcel->getActiveSheet()->setCellValue('H'.$col,$genderbase[$i]['marital_status']);
         $objPHPExcel->getActiveSheet()->setCellValue('I'.$col,$genderbase[$i]['case_type']);
         $objPHPExcel->getActiveSheet()->setCellValue('J'.$col,$genderbase[$i]['case_status']);
    }
    $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel,'Excel5');
        header('Content-Type: application/vnd.ms-excel');
    header('Content-Disposition: attachment;filename="Report-'.$type.'.xls"');
    header('Cache-Control: max-age=0');
    $objWriter->save('php://output');
    exit();
}
}
else{
    
   $content = "
<page backcolor = 'white'>
<div class='cntr' style='margin-top:350px;margin-left:350px'>
    
    <br>
    <img src='assets/images/logoLSF.png'/>
    <h1 style='float:left'>{$type}</h1>
    </div>
</page>";
   
   $content .='<page backcolor = "white" width="auto">
    <table  width="auto" height="auto" style="margin:10px;" border="1px">
    <thead>
                    <tr>
                        <th width="12.5%">Date</th>
                        <th width="12.5%">Mobile</th>
                        <th width="12.5%">Submitted By</th>
                        <th width="12.5%">Unit</th>
                        <th width="12.5%">Mobile</th>
                        <th width="12.5%">Gender</th>
                        <th width="12.5%">Age</th>
                        <th width="12.5%">Education</th>
                        <th width="12.5%">Marital Status</th>
                        <th width="12.5%">Type of Case</th>
                        <th width="12.5%">Case Status</th>
                    </tr></thead><tbody>';
   
           for($i=0;$i<count($genderbase);$i++){
               $time = date($genderbase[$i]['Submitted']); 
               $time=strtotime($time);
               $time = date("Y-m-d",$time);
               
               $mobile = $genderbase[$i]['phone_number'];
               $name = $genderbase[$i]['name'];
               $unit = $genderbase[$i]['unit_name'];
               $gender = $genderbase[$i]['gender'];
               $age = $genderbase[$i]['age'];
               $education = $genderbase[$i]['education'];
               $marital = $genderbase[$i]['marital_status'];
               $type = $genderbase[$i]['case_type'];
               $status = $genderbase[$i]['case_status'];
                 $content .=<<<EOD
<tr bgcolor="#EAF8FF">
<td>
$time
</td>
<td>
$mobile
</td>
<td>
$name
</td>
<td>
$unit
</td>
<td>
$gender
</td>
<td>
$age
</td>
<td>
$education
</td>
<td>
$marital
</td>
<td>
$type
</td>
<td>
$status
</td>
</tr>
EOD
                         ;
           }
                  $content .= '</tbody></table>
</page>';
   
   $html2pdf = new HTML2PDF('P','A4','en');
    $html2pdf->WriteHTML($content);
    $html2pdf->Output('Report-'.$type.'.pdf');
     header('Content-Type: application/pdf');
    header('Content-Disposition: attachment;filename=Report-'.$type.'.pdf');
    
}

}
?>   
   
       
       
 









