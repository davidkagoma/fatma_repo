<script type="text/javascript">
    $('#disputes-monthly').highcharts({
        chart: {
            type: 'line'
        },
        title: {
            text: ''
        },
        subtitle: {
            text: '',
             x: -20
        },
 xAxis: {
categories: ['December','January','February']      
        },
        
        yAxis: {
            title: {
                text: 'Number of Disputes'
            },
            min: 0
        },
           plotOptions: {
            line: {
                dataLabels: {
                    enabled: true
                },
                enableMouseTracking: false
            }
        },

tooltip: {
                shared: true,
                crosshairs: true
            },

            plotOptions: {
                series: {
                    cursor: 'pointer',
                    point: {
                        events: {
                            click: function (e) {
                                hs.htmlExpand(null, {
                                    pageOrigin: {
                                        x: e.pageX || e.clientX,
                                        y: e.pageY || e.clientY
                                    },
                                    headingText: this.series.name,
                                    maincontentText: Highcharts.dateFormat('%A, %b %e, %Y', this.x) + ':<br/> ' +
                                        this.y + ' visits',
                                    width: 200
                                });
                            }
                        }
                    },
                    marker: {
                        lineWidth: 1
                    }
                }
            },
      


                        series: [{
                        name : 'Total Disputes',
                        data :[<?php foreach($totl as $key){
                        echo $key['totaldisputes'] . ","; }?>]
        },
                 {
            name: 'Disputes Resolved',
            data: [<?php foreach($solv as $key){echo $key['solved'] .",";} ?>]
        },

                 {
            name: 'Disputes Reffered',
            data: [<?php foreach($ref as $key){ echo $key['referred'] . ",";  } ?>]
        },


         {
            name: 'End Without Solution',
            data: [<?php foreach($endnotsolv as $key){ echo $key['endnotsolved'] . ",";}?>]
        },

        {
            name: 'Ongoing Disputes',
            data: [<?php foreach($ongng as $key){ echo $key['id'] . ",";}?>]
        },
]
    });
</script>
