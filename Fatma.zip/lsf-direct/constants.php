<?php

define('HOST','localhost');
define('DB_NAME','lsf_platform');
define('DB_USER','root');
define('DB_PASS','');
define('API_URL','http://188.64.187.118/api/sendsms/');

