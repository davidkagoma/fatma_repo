<?php
include_once 'query.php';

$query = new query();

if($_SESSION['type']=='super admin'){
    
    $where = "1=1";
    
}

else{
    
    $sql = "SELECT unit_id from paralegals where login_id = {$_SESSION['loginid']}";
    $result = $query :: select($sql);
    $row = mysql_fetch_array($result);
    $unitid = $row['unit_id'];
    
    $where = "unit_id = {$unitid}";
}


$sql = "SELECT COUNT(CASE WHEN gender = 'Male' THEN 1 END) AS 'Male',COUNT(CASE WHEN gender = 'Female' THEN 1 END) AS 'Female' FROM LegalAidDirectView where $where";
$result = $query :: select($sql);
$row = mysql_fetch_array($result);
$aidmale = $row['Male'];
$aidfemale = $row['Female'];


$sql = "SELECT SUM(Male) AS 'Male',SUM(`Female`) AS 'Female' FROM LegalEducationDirectView  WHERE $where";
$result = $query :: select($sql);
$row = mysql_fetch_array($result);
$edumale = $row['Male'];
$edufemale = $row['Female'];

$sql="SELECT count(record_id) as `totaldisputes`,monthname(Submitted) as `month`,month(Submitted) FROM LegalAidDirectView  WHERE    year(Submitted)in(2015,2016)  AND  $where group by monthname(Submitted),month(Submitted) order by Year(Submitted) asc";
			$total=$query :: select ($sql);
                        
                        $totl = array();
                        while($totrow = mysql_fetch_array($total)){    
                            $totl[] = $totrow;
}

$sql  = "SELECT count(record_id) as `id`,monthname(Submitted) FROM LegalAidDirectView  WHERE   case_status  = 'Ongoing' and year(Submitted)in(2015,2016)  AND $where group by monthname(Submitted) order by Year(Submitted) asc";			
			$ongoing = $query :: select ($sql);
                        $ongng = array();
                        while($row = mysql_fetch_array($ongoing)){
                            $ongng[] = $row;     
                        }
                        
                        //Referred disputes 
			$sql="SELECT count(record_id) as `referred`,monthname(Submitted) FROM LegalAidDirectView  WHERE   case_status='Reffered' and year(Submitted)in(2015,2016)  AND $where group by monthname(Submitted) order by Year(Submitted) asc";
			$referred= $query :: select ($sql);
			$ref  = array();
                        while($refrow = mysql_fetch_array($referred)){
                            $ref[] = $refrow;
                        }
                        
                        //solved
			$sql="SELECT count(record_id) as `solved`,monthname(Submitted) as `month` FROM LegalAidDirectView  WHERE   case_status='Resolved' and year(Submitted)in(2015,2016)  AND $where group by monthname(Submitted) order by Year(Submitted) asc";
			$solved=$query :: select ($sql);
			$solv = array();
                        while($solvrow = mysql_fetch_array($solved)){    
                            $solv[] = $solvrow;
                        }
			//end without solution
                        $sql="SELECT count(record_id) as `endnotsolved`,monthname(Submitted) as `month` FROM LegalAidDirectView WHERE   case_status='End without solution' and year(Submitted)in(2015,2016)  AND $where group by monthname(Submitted) order by Year(Submitted) asc";
			$endnotsolved= $query :: select ($sql);
                        $endnotsolv = array();
                        while($endnotsolvrow = mysql_fetch_array($endnotsolved)){    
                            $endnotsolv[] = $endnotsolvrow;
}



$sql = "SELECT count(paralegal_id) from paralegals where $where";

$result = $query :: select($sql);
$paralegal = mysql_fetch_row($result);
$paralegal = $paralegal[0];
    

 $sql = "SELECT monthname(Submitted) as 'month' from LegalAidDirectView WHERE  $where group by month(Submitted) order by Year(Submitted)";
                        $result = $query :: select($sql);
                        $months = array();
                        
                        while($monthrow = mysql_fetch_array($result)){
                            
                        $months[] = $monthrow;     
                            
                        }
                        
 $sql = "SELECT count(*) from LegalAidDirectView WHERE $where ";
 $result = $query :: select($sql);
                       $aidclients = mysql_fetch_row($result);
$aidclients = $aidclients[0];


$sql = "SELECT count(*) as 'tot',unit_name FROM LegalAidDirectView group by unit_name ";
$result = $query :: select($sql);
$unitwise = array();

while($row = mysql_fetch_array($result)){
                            
                        $unitwise[] = $row;     
                            
                        }
                        
                        
function getCount($view,$unitname){
    include('db.php');
    if($view == "LegalAidDirectView"){
        
        $sql = "SELECT count(*) as 'tot' FROM {$view} where  unit_name like '%{$unitname}%' ";
    }
    else{
    $sql = "SELECT sum(Male)+SUM(Female) as 'tot' FROM {$view} where  unit_name like '%{$unitname}%' ";
    }
    
    $result = mysql_query($sql);
    $count = mysql_fetch_row($result);
    mysql_close();
    return $count[0];
}